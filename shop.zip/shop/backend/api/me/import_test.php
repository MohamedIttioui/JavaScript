<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$sql = "SELECT * FROM 013_partners LIMIT 1";
$result = $conn->query($sql);
$partner = $result->fetch_assoc();

echo "<h2>Partner encontrado en ME:</h2>";
var_dump($partner);

echo "<h2>Probando llamada al partner:</h2>";

$opts = [
  "http" => [
    "header" => "X-API-KEY: " . $partner['api_key']
  ]
];
$context = stream_context_create($opts);

$json = file_get_contents($partner['api_url_products'], false, $context);

echo "<h2>Respuesta del partner:</h2>";
var_dump($json);

echo "<h2>JSON decodificado:</h2>";
var_dump(json_decode($json, true));