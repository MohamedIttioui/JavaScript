<?php
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/api/me/_auth.php';
check_api_key_me($conn);

// Obtener partner desde la tabla 013_partners
$sql = "SELECT * FROM 013_partners LIMIT 1";
$result = $conn->query($sql);
$partner = $result->fetch_assoc();

if (!$partner) {
    echo json_encode(["error" => "No partner configured in ME"]);
    exit;
}

$partner_api_key = $partner['api_key'];
$partner_url = $partner['api_url_products'];
$partner_margin = floatval($partner['partner_margin']); // margen de 0.60

//   PETICIÓN AL PARTNER (cURL)
$ch = curl_init($partner_url);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "X-API-KEY: $partner_api_key"
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);

curl_close($ch);

// Validar respuesta
if ($error || $http_code !== 200) {
    echo json_encode([
        "error" => "Partner request failed",
        "http_code" => $http_code,
        "curl_error" => $error,
        "raw" => $response
    ]);
    exit;
}
$data = json_decode($response, true);
if (!$data || !isset($data["products"])) {
    echo json_encode([
        "error" => "Invalid partner response",
        "raw" => $response
    ]);
    exit;
}
$imported = 0;

foreach ($data["products"] as $p) {
    // ID externo
    $id = intval($p["id"]);
    // Campos obligatorios
    $name = $conn->real_escape_string($p["name"]);
    $price = floatval($p["price"]); // precio de venta
    $stock = intval($p["stock"]);
    // Calcular coste
    $partner_cost_price = $price * $partner_margin;

    $desc = $conn->real_escape_string($p["description"] ?? "");
    $format = $conn->real_escape_string($p["format"] ?? "");
    $flavor = $conn->real_escape_string($p["flavor"] ?? "");
    $image = $conn->real_escape_string($p["image"] ?? "");
    $sql = "INSERT INTO 013_products (name, description, format, flavor, price, vat_included, stock, image, is_external, external_id, partner_id, partner_cost_price, is_featured)
        VALUES ('$name', '$desc', '$format', '$flavor', $price, 1, $stock, '$image', 1, $id, {$partner['partner_id']}, $partner_cost_price, 0)
    ";
    if (!$conn->query($sql)) {
        echo json_encode([
            "sql_error" => $conn->error,
            "query" => $sql
        ]);
        exit;
    }
    $imported++;
}
echo json_encode([
    "status" => "ok",
    "imported" => $imported
]);