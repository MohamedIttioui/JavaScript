<?php
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/api/me/_auth.php';
check_api_key_me($conn);

if (!isset($_GET['order_id'])) {
  echo json_encode(["error" => "Missing order_id"]);
  exit;
}

$order_id = intval($_GET['order_id']);

// Obtener partner (de momento solo 1)
$sql = "SELECT * FROM 013_partners LIMIT 1";
$result = $conn->query($sql);
$partner = $result->fetch_assoc();

if (!$partner) {
  echo json_encode(["error" => "No partner configured"]);
  exit;
}

$partner_api_key = $partner['api_key'];
$partner_url = $partner['api_url_orders'];

// Obtener orden
$sql = "SELECT * FROM 013_orders WHERE order_id = $order_id";
$order_res = $conn->query($sql);
$order = $order_res->fetch_assoc();

if (!$order) {
  echo json_encode(["error" => "Order not found"]);
  exit;
}

// Obtener SOLO los items del partner
$sql = "SELECT * FROM 013_order_items 
        WHERE order_id = $order_id 
        AND is_external = 1
        AND partner_id = {$partner['partner_id']}";

$items_res = $conn->query($sql);
$items = [];
$partner_total = 0;

while ($row = $items_res->fetch_assoc()) {
  // Seguridad: nunca enviar productos internos
  if ($row["external_product_id"] === null) {
    continue;
  }

  $items[] = [
    "id"    => intval($row["external_product_id"]),
    "name"  => $row["product_name"],
    "qty"   => intval($row["quantity"]),
    "price" => floatval($row["price"])
  ];

  // Calcular total SOLO del partner
  $partner_total += floatval($row["price"]) * intval($row["quantity"]);
}

// SI NO HAY ITEMS DEL PARTNER, NO ENVIAR NADA
if (count($items) === 0) {
  echo json_encode([
    "status" => "no_partner_items",
    "message" => "This order does not contain any products from this partner.",
    "order_id" => $order_id
  ]);
  exit;
}

// Construir JSON
$payload = [
  "partner_id" => $partner['partner_id'],
  "order" => [
    "id"               => $order["order_id"],
    "order_number"     => $order["order_number"],
    "total"            => $partner_total, // SOLO total del partner
    "shipping_address" => $order["shipping_address"],
    "payment_method"   => $order["payment_method"],
    "notes"            => $order["notes"],
    "items"            => $items
  ]
];

$json_payload = json_encode($payload);

// Enviar al partner (cURL)
$ch = curl_init($partner_url);

curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Content-Type: application/json",
  "X-API-KEY: $partner_api_key"
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response  = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error     = curl_error($ch);

curl_close($ch);

// Respuesta final
echo json_encode([
  "status"     => "sent",
  "http_code"  => $http_code,
  "payload"    => $payload,
  "response"   => json_decode($response, true),
  "curl_error" => $error
]);
