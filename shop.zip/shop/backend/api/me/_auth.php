<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
// API KEY de ME
$MY_API_KEY = "b7c4f9e2d1a83c4f7b9d2a6c3f1e8b4d9c7a2f1b6e3d4c8a9f0b1c2d3e4f5a6";

function check_api_key_me($conn)
{
  global $MY_API_KEY;

  // Obtener headers (si falla, array vacío)
  $headers = function_exists('getallheaders') ? getallheaders() : [];
  // Fallback: si no llega header, usar la API key de ME
  $apiKey = $headers['X-API-KEY'] ?? $MY_API_KEY;
  // Si coincide con la clave de ME -> OK
  if ($apiKey === $MY_API_KEY) {
    return true;
  }
  // Si coincide con la clave de un partner -> OK
  $sql = "SELECT partner_id FROM 013_partners WHERE api_key = '$apiKey' LIMIT 1";
  $result = $conn->query($sql);

  if ($result && $result->num_rows === 1) {
    return true;
  }

  http_response_code(403);
  echo json_encode(["error" => "Invalid API key"]);
  exit;
}