<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$apiKey = 'zpka_ec233d45dd1c40309991a19758e3a39e_32cb281b'; // API Key de AccuWeather
$locationKey = '305482'; // Mahón

// Leer cookie (1 = guardar, 0 = no guardar)
$save = $_COOKIE['saveWeather'] ?? 0;
$baseUrl = 'https://dataservice.accuweather.com';

$currentUrl = "$baseUrl/currentconditions/v1/$locationKey?apikey=$apiKey&details=true";
$forecastUrl = "$baseUrl/forecasts/v1/daily/5day/$locationKey?apikey=$apiKey&metric=true";

$currentJson = file_get_contents($currentUrl);
$forecastJson = file_get_contents($forecastUrl);

if ($currentJson === false || $forecastJson === false) {
  http_response_code(500);
  echo json_encode(['error' => 'No se pudo obtener el tiempo']);
  exit;
}

$current = json_decode($currentJson, true);
$forecast = json_decode($forecastJson, true);

$data = [
  "current" => $current[0],
  "forecast" => array_slice($forecast["DailyForecasts"], 0, 3)
];

// Guardar en BD si la cookie está activa
if ($save == 1) {
  $json = $conn->real_escape_string(json_encode($data));
  $conn->query("INSERT INTO 013_weather (data) VALUES ('$json')");
}

echo json_encode($data);
?>