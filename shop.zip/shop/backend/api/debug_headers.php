<?php
header('Content-Type: application/json');

$headers = getallheaders();

echo json_encode([
  "received_headers" => $headers
]);
