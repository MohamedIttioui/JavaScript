<?php
header('Content-Type: application/json');

require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/partner_db_connect.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/api/partner/_auth.php';

// Validar API key
check_api_key_partner($conn);

if (!isset($_GET['order_id'])) {
  echo json_encode(["error" => "Missing order_id"]);
  exit;
}

$order_id = intval($_GET['order_id']);

// Obtener info de ME
$sql = "SELECT * FROM 013_partners LIMIT 1";
$result = $conn->query($sql);
$me = $result->fetch_assoc();

$me_api_key = $me['api_key'];
$me_url = $me['api_url_orders'];

// Obtener pedido
$sql = "SELECT * FROM 013_orders WHERE order_id = $order_id";
$order_res = $conn->query($sql);
$order = $order_res->fetch_assoc();

// Obtener items
$sql = "SELECT * FROM 013_order_items WHERE order_id = $order_id";
$items_res = $conn->query($sql);

$items = [];
while ($row = $items_res->fetch_assoc()) {
  $items[] = [
    "id" => intval($row["external_product_id"] ?: $row["product_id"]),
    "name" => $row["product_name"],
    "qty" => intval($row["quantity"]),
    "price" => floatval($row["price"])
  ];
}

// JSON a enviar
$payload = json_encode([
  "partner_id" => $me['partner_id'],
  "order" => [
    "id" => $order["order_id"],
    "order_number" => $order["order_number"],
    "total" => floatval($order["total"]),
    "items" => $items
  ]
]);

// Enviar a ME
$opts = [
  "http" => [
    "method" => "POST",
    "header" => "Content-Type: application/json\r\nX-API-KEY: $me_api_key",
    "content" => $payload
  ]
];

$context = stream_context_create($opts);
$response = file_get_contents($me_url, false, $context);

echo json_encode([
  "status" => "sent",
  "response" => json_decode($response, true)
]);