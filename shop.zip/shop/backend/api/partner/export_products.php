<?php
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/partner_db_connect.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/api/partner/_auth.php';
check_api_key_partner($conn);

// Exportar SOLO productos propios del partner
$sql = "SELECT product_id, name, description, format, flavor, price, vat_included, stock, image
        FROM 013_products
        WHERE is_external = 0";

$result = $conn->query($sql);

$products = [];

while ($row = $result->fetch_assoc()) {
    $products[] = [
        "id" => (int) $row["product_id"],
        "name" => $row["name"],
        "description" => $row["description"],
        "format" => $row["format"],
        "flavor" => $row["flavor"],
        "price" => (float) $row["price"],
        "vat_included" => (bool) $row["vat_included"],
        "stock" => (int) $row["stock"],
        "image" => $row["image"]
    ];
}

echo json_encode([
    "supplier" => "partner",
    "products" => $products
], JSON_PRETTY_PRINT);