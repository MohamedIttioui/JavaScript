<?php
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/partner_db_connect.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/api/partner/_auth.php';

// Validar API key
check_api_key_partner($conn);

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data["order"])) {
  http_response_code(400);
  echo json_encode(["error" => "Invalid JSON"]);
  exit;
}

$order = $data["order"];
$partner_id = intval($data["partner_id"]);

$order_number = $conn->real_escape_string($order["order_number"]);
$total = floatval($order["total"]);
$external_order_id = intval($order["id"]);

$shipping_address = $conn->real_escape_string($order["shipping_address"] ?? '');
$payment_method = $conn->real_escape_string($order["payment_method"] ?? '');
$notes = $conn->real_escape_string($order["notes"] ?? '');

// Insertar pedido externo
$sql = "INSERT INTO 013_orders
    (order_number, total, status, is_external, external_id, partner_id, shipping_address, payment_method, notes)
    VALUES ('$order_number',$total,'pending',1,$external_order_id,$partner_id,'$shipping_address','$payment_method','$notes')";

$conn->query($sql);
$order_id = $conn->insert_id;

// Insertar items
foreach ($order["items"] as $item) {

  $external_product_id = intval($item["id"]);
  $product_name = $conn->real_escape_string($item["name"]);
  $qty = intval($item["qty"]);
  $price = floatval($item["price"]);

  $sql_item = "INSERT INTO 013_order_items (order_id, product_id, external_product_id, product_name, quantity, price)
        VALUES ($order_id, NULL, $external_product_id, '$product_name', $qty, $price)";

  $conn->query($sql_item);
}

echo json_encode([
  "status" => "ok",
  "order_id" => $order_id
]);
