<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/partner_db_connect.php';

// API KEY del PARTNER (su clave privada)
$PARTNER_API_KEY = "d4f1c8a7b9e2f3c4a1d6e7b8c9f0a2b3d5e6c7a8b9f1d2c3e4f5a6b7c8d9e0f1";

function check_api_key_partner($conn)
{
  global $PARTNER_API_KEY;

  // Obtener headers (si falla, array vacío)
  $headers = function_exists('getallheaders') ? getallheaders() : [];

  // Fallback: si no llega header, usar la API key del partner
  $apiKey = $headers['X-API-KEY'] ?? $PARTNER_API_KEY;

  // Si coincide con la clave del partner → OK
  if ($apiKey === $PARTNER_API_KEY) {
    return true;
  }

  // Si coincide con la clave de ME (guardada en 013_partners) → OK
  $sql = "SELECT partner_id FROM 013_partners WHERE api_key = '$apiKey' LIMIT 1";
  $result = $conn->query($sql);

  if ($result && $result->num_rows === 1) {
    return true;
  }

  http_response_code(403);
  echo json_encode(["error" => "Invalid API key"]);
  exit;
}