<?php
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/partner_db_connect.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/api/partner/_auth.php';

// Validar API key
check_api_key_partner($conn);

// Obtener info de ME desde la tabla 013_partners del partner
$sql = "SELECT * FROM 013_partners LIMIT 1";
$result = $conn->query($sql);
$me = $result->fetch_assoc();

$me_api_key = $me['api_key'];
$me_url = $me['api_url_products'];

// Llamar a ME
$opts = [
  "http" => [
    "header" => "X-API-KEY: $me_api_key"
  ]
];
$context = stream_context_create($opts);

$json = file_get_contents($me_url, false, $context);
$data = json_decode($json, true);

if (!$data || !isset($data["products"])) {
  echo json_encode(["error" => "Invalid ME response"]);
  exit;
}

$imported = 0;

foreach ($data["products"] as $p) {

  $id = intval($p["id"]);
  $name = $conn->real_escape_string($p["name"]);
  $desc = $conn->real_escape_string($p["description"]);
  $format = $conn->real_escape_string($p["format"]);
  $flavor = $conn->real_escape_string($p["flavor"]);
  $price = floatval($p["price"]);
  $stock = intval($p["stock"]);
  $image = $conn->real_escape_string($p["image"]);

  $sql = "INSERT INTO 013_products
        (name, description, format, flavor, price, vat_included, stock, image, is_external, external_id, partner_id)
        VALUES ('$name', '$desc', '$format', '$flavor', $price, 1, $stock, '$image', 1, $id, {$me['partner_id']})
    ";

  $conn->query($sql);
  $imported++;
}

echo json_encode([
  "status" => "ok",
  "imported" => $imported
]);