<?php

function curlGet($url)
{
  $ch = curl_init();

  curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 10
  ]);

  $response = curl_exec($ch);
  $error = curl_error($ch);

  curl_close($ch);

  if ($error) {
    return false;
  }

  return $response;
}

$apiKey = 'zpka_ec233d45dd1c40309991a19758e3a39e_32cb281b';
$locationKey = '305482';

$currentUrl = "https://dataservice.accuweather.com/currentconditions/v1/$locationKey?apikey=$apiKey&details=true";
$forecastUrl = "https://dataservice.accuweather.com/forecasts/v1/daily/5day/$locationKey?apikey=$apiKey&metric=true";

$currentJson = curlGet($currentUrl);
$forecastJson = curlGet($forecastUrl);

if (!$currentJson || !$forecastJson) {
  echo json_encode(["error" => "Error con cURL"]);
  exit;
}

$current = json_decode($currentJson, true);
$forecast = json_decode($forecastJson, true);

echo json_encode([
  "current" => $current[0],
  "forecast" => array_slice($forecast["DailyForecasts"], 0, 3)
]);
