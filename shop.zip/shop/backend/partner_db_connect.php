<?php
//backend/partner_db_connect.php
$host = 'localhost';
$user = 'root';
$pwd = '';
$database = 'shop_partner';

$conn = new mysqli($host, $user, $pwd, $database, 3307);

if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}

$conn->set_charset('utf8mb4');