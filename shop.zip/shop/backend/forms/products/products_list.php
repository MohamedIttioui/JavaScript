<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/functions/show_products.php';
?>
<link rel="stylesheet" href="/student013/shop/backend/css/products.css">

<?php $userType = $userType ??= 'guest'; ?>
<div class="container">
    <h1>Productos destacados</h1>
    <?php show_products($conn, $userType); ?>
</div>
<?php
$conn->close();
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php';
?>