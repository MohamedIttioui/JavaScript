<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
$userType = $_SESSION['user_type'] ?? 'guest';
?>

<form method="POST" action="/student013/shop/backend/database/db_customers/db_customer_insert.php"
  enctype="multipart/form-data" class="form">

  <?php if ($userType === 'admin'): ?>
    <h2>Insertar Cliente (Modo Admin)</h2>
  <?php else: ?>
    <h2>Registrarse como Nuevo Cliente</h2>
    <input type="hidden" name="redirect_checkout_flow" value="true">
  <?php endif; ?>

  <!-- Datos personales -->
  <div class="form-group">
    <label>Nombre</label>
    <input type="text" name="first_name" required>
  </div>

  <div class="form-group">
    <label>Apellidos</label>
    <input type="text" name="last_name" required>
  </div>

  <div class="form-group">
    <label>NIF</label>
    <input type="text" name="nif" required>
  </div>

  <div class="form-group">
    <label>Teléfono</label>
    <input type="text" name="phone">
  </div>

  <div class="form-group">
    <label>Imagen de perfil</label>
    <input type="file" name="image">
  </div>

  <!-- Datos de acceso -->
  <div class="form-group">
    <label>Email</label>
    <input type="email" name="email" required>
  </div>

  <div class="form-group">
    <label>Contraseña</label>
    <input type="password" name="password" required>
  </div>

  <div class="form-group">
    <label>Confirmar contraseña</label>
    <input type="password" name="confirm_password" required>
  </div>

  <!-- Dirección -->
  <div class="form-group">
    <label>Dirección</label>
    <input type="text" name="address" required>
  </div>

  <div class="form-group">
    <label>Ciudad</label>
    <input type="text" name="city" required>
  </div>

  <div class="form-group">
    <label>Código Postal</label>
    <input type="text" name="zip_code" required>
  </div>

  <div class="form-group">
    <label>País</label>
    <select name="country" required>
      <option value="">Seleccionar País</option>
      <option value="es">España</option>
      <option value="fr">Francia</option>
      <option value="pt">Portugal</option>
    </select>
  </div>

  <div class="form-actions">
    <?php if ($userType === 'admin'): ?>
      <input type="submit" value="Insertar Cliente" class="btn-submit">
    <?php else: ?>
      <input type="submit" value="Registrarse" class="btn-submit">
    <?php endif; ?>
  </div>
</form>

<?php require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>