<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/database/db_partners/db_partner_billing.php';

$summary = getPartnerBillingSummary($conn);
?>

<div class="backend-container">

  <h2>Facturación del Partner (Mensual)</h2>

  <h3>Resumen</h3>

  <table class="backend-table">
    <tr>
      <th>Partner ID</th>
      <th>Total Ventas</th>
      <th>Coste Partner</th>
      <th>Beneficio</th>
      <th>Detalles</th>
    </tr>

    <?php while ($row = $summary->fetch_assoc()): ?>
      <?php
      $profitClass = $row['total_profit'] >= 0 ? "backend-profit-positive" : "backend-profit-negative";
      ?>
      <tr>
        <td><?= $row['partner_id'] ?></td>
        <td class="num"><?= number_format($row['total_sales'], 2) ?> €</td>
        <td class="num"><?= number_format($row['total_partner_cost'], 2) ?> €</td>
        <td class="num <?= $profitClass ?>"><?= number_format($row['total_profit'], 2) ?> €</td>
        <td><a href="?partner_id=<?= $row['partner_id'] ?>">Ver detalles</a></td>
      </tr>
    <?php endwhile; ?>
  </table>

  <?php
  if (isset($_GET['partner_id'])):
    $partner_id = intval($_GET['partner_id']);
    $details = getPartnerBillingDetails($conn, $partner_id);
  ?>

    <h3>Detalles del Partner #<?= $partner_id ?></h3>

    <table class="backend-table">
      <tr>
        <th>Pedido</th>
        <th>Fecha</th>
        <th>Producto</th>
        <th>Cantidad</th>
        <th>Precio Venta</th>
        <th>Coste Partner</th>
        <th>Total Venta</th>
        <th>Total Coste</th>
        <th>Beneficio</th>
      </tr>

      <?php while ($row = $details->fetch_assoc()): ?>
        <?php
        $profitClass = $row['profit'] >= 0 ? "backend-profit-positive" : "backend-profit-negative";
        ?>
        <tr>
          <td><?= $row['order_number'] ?></td>
          <td><?= $row['order_date'] ?></td>
          <td><?= $row['product_name'] ?></td>
          <td class="num"><?= $row['quantity'] ?></td>
          <td class="num"><?= number_format($row['sale_price'], 2) ?> €</td>
          <td class="num"><?= number_format($row['partner_cost_price'], 2) ?> €</td>
          <td class="num"><?= number_format($row['total_sale_amount'], 2) ?> €</td>
          <td class="num"><?= number_format($row['partner_total_cost'], 2) ?> €</td>
          <td class="num <?= $profitClass ?>"><?= number_format($row['profit'], 2) ?> €</td>
        </tr>
      <?php endwhile; ?>
    </table>

  <?php endif; ?>

</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>