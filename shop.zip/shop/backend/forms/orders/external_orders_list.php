<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/database/db_partners/db_partner_external_orders.php';

$result = getExternalOrders($conn);
?>
<div class="backend-container">
    <h2>Pedidos Externos (Partner)</h2>

    <table class="backend-table">
        <tr>
            <th>Pedido</th>
            <th>Fecha</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio Venta</th>
            <th>Coste Partner</th>
            <th>Total Venta</th>
            <th>Total Coste</th>
            <th>Beneficio</th>
            <th>Partner</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['order_number'] ?></td>
                <td><?= $row['updated_at'] ?></td>
                <td><?= $row['product_name'] ?></td>
                <td class="num"><?= $row['quantity'] ?></td>
                <td class="num"><?= number_format($row['sale_price'], 2) ?> €</td>
                <td class="num"><?= number_format($row['partner_cost_price'], 2) ?> €</td>
                <td class="num"><?= number_format($row['total_sale'], 2) ?> €</td>
                <td class="num"><?= number_format($row['total_cost'], 2) ?> €</td>
                <?php
                $profit = $row['profit'];
                $profitClass = $profit >= 0 ? "backend-profit-positive" : "backend-profit-negative";
                ?>
                <td class="num <?= $profitClass ?>"><?= number_format($profit, 2) ?> €</td>
                <td><?= $row['name'] ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>