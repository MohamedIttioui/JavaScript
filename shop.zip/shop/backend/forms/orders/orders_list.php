<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$orders = [];
if ($userType === 'admin') {
  $sql = "SELECT o.order_id, o.order_number, o.order_date, o.total, o.status,
                   c.first_name, c.last_name, c.email
            FROM 013_orders o
            JOIN 013_customers c ON o.customer_id = c.customer_id
            ORDER BY o.order_id DESC
            LIMIT 20";
  $res = $conn->query($sql);
  if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
      $orders[] = $row;
    }
  }
}
$conn->close();
?>
<link rel="stylesheet" href="/student013/shop/backend/css/orders.css">
<div class="container">
  <h1>Registrated orders</h1>
  <div class="orders-flex">
    <?php if ($userType === 'admin'): ?>
      <?php if (!empty($orders)): ?>
        <?php foreach ($orders as $order): ?>
          <div class="order-card">
            <img src="/student013/shop/assets/icons/orders.svg" alt="Order <?= htmlspecialchars($order['order_number']) ?>"
              class="order-img">
            <h3>Order <?= htmlspecialchars($order['order_number']) ?></h3>
            <p><strong>Customer:</strong>
              <?= htmlspecialchars($order['first_name'] . ' ' . $order['last_name']) ?>
            </p>
            <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
            <p><strong>Date:</strong> <?= htmlspecialchars($order['order_date']) ?></p>
            <p><strong>Total:</strong> €<?= htmlspecialchars($order['total']) ?></p>
            <p><strong>State:</strong> <?= htmlspecialchars($order['status']) ?></p>
            <div class="buttons">
              <a href="/student013/shop/backend/database/db_orders/db_order_select.php?order_id=<?= $order['order_id'] ?>"
                class="select">Show</a>
              <a href="/student013/shop/backend/forms/orders/order_update.php?order_id=<?= $order['order_id'] ?>"
                class="update">Update</a>
              <a href="/student013/shop/backend/forms/orders/order_delete.php?order_id=<?= $order['order_id'] ?>"
                class="delete">Delete</a>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p>No hay órdenes registradas.</p>
      <?php endif; ?>
    <?php else: ?>
      <p>No tienes permisos para ver esta sección.</p>
    <?php endif; ?>
  </div>
</div>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>