<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';

$log_file = $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/logs/external_orders.log';

?>

<div class="backend-container">
    <h2>Log de Pedidos Externos</h2>

    <?php if (!file_exists($log_file)): ?>
        <p>No hay logs todavía.</p>
    <?php else: ?>
        <pre style="
            background:#111;
            color:#0f0;
            padding:20px;
            border-radius:8px;
            max-height:600px;
            overflow-y:auto;
            font-size:13px;
        ">
<?= htmlspecialchars(file_get_contents($log_file)) ?>
        </pre>
    <?php endif; ?>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>