<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$orders = [];
if ($userType === 'customer' && !empty($_SESSION['customer_id'])) {
  $customer_id = intval($_SESSION['customer_id']);
  $sql = "SELECT order_id, order_number, order_date, total, status
            FROM 013_orders
            WHERE customer_id = $customer_id
            ORDER BY order_id DESC";
  $res = $conn->query($sql);
  if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
      $orders[] = $row;
    }
  }
}
$conn->close();
?>
<link rel="stylesheet" href="/student013/shop/backend/css/orders.css">
<div class="container">
  <h1>Mis pedidos</h1>
  <div class="orders-flex">
    <?php if (!empty($orders)): ?>
      <?php foreach ($orders as $order): ?>
        <div class="order-card">
          <img src="/student013/shop/assets/icons/orders.svg" alt="Orden <?= htmlspecialchars($order['order_number']) ?>"
            class="order-img">
          <h3>Orden <?= htmlspecialchars($order['order_number']) ?></h3>
          <p><strong>Fecha:</strong> <?= htmlspecialchars($order['order_date']) ?></p>
          <p><strong>Total:</strong> €<?= htmlspecialchars($order['total']) ?></p>
          <p><strong>Estado:</strong> <?= htmlspecialchars($order['status']) ?></p>
          <div class="buttons">
            <a href="/student013/shop/backend/database/db_orders/db_order_select.php?order_id=<?= $order['order_id'] ?>"
              class="select">Ver detalle</a>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p>No tienes pedidos registrados.</p>
    <?php endif; ?>
  </div>
</div>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>