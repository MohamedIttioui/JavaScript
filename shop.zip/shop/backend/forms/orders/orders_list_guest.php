<?php
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$guest_id = $_COOKIE['guest_id'] ?? null;
$orders = [];

if ($guest_id) {
  $guest_id_safe = $conn->real_escape_string($guest_id);

  $sql = "SELECT order_id, order_number, order_date, total, status
            FROM 013_orders
            WHERE guest_id = '$guest_id_safe'
            ORDER BY order_id DESC";

  $res = $conn->query($sql);

  if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
      $orders[] = $row;
    }
  }
}

$conn->close();
?>

<link rel="stylesheet" href="/student013/shop/backend/css/orders.css">

<div class="container">
  <h1>Mis pedidos (Invitado)</h1>

  <?php if (!$guest_id): ?>
    <p>No tienes identificador de invitado. No es posible mostrar pedidos.</p>

  <?php elseif (empty($orders)): ?>
    <p>No tienes pedidos registrados como invitado.</p>

  <?php else: ?>
    <div class="orders-flex">
      <?php foreach ($orders as $order): ?>
        <div class="order-card">
          <img src="/student013/shop/assets/icons/orders.svg" alt="Orden <?= htmlspecialchars($order['order_number']) ?>"
            class="order-img">

          <h3>Orden <?= htmlspecialchars($order['order_number']) ?></h3>
          <p><strong>Fecha:</strong> <?= htmlspecialchars($order['order_date']) ?></p>
          <p><strong>Total:</strong> €<?= htmlspecialchars($order['total']) ?></p>
          <p><strong>Estado:</strong> <?= htmlspecialchars($order['status']) ?></p>

          <div class="buttons">
            <a href="/student013/shop/backend/database/db_orders/db_order_select.php?order_id=<?= $order['order_id'] ?>"
              class="select">Ver detalle</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>