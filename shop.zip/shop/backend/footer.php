<!-- FOOTER -->
<footer class="footer">
    <div class="social-links">
        <a href="https://www.facebook.com/NutriCore" target="_blank">
            <img src="/student013/shop/assets/icons/facebook.svg" alt="Facebook" width="32">
        </a>
        <a href="https://twitter.com/NutriCore" target="_blank">
            <img src="/student013/shop/assets/icons/twitter.svg" alt="Twitter" width="32">
        </a>
        <a href="https://www.instagram.com/NutriCore" target="_blank">
            <img src="/student013/shop/assets/icons/instagram.svg" alt="Instagram" width="32">
        </a>
        <a href="https://www.linkedin.com/company/NutriCore" target="_blank">
            <img src="/student013/shop/assets/icons/linkedin.svg" alt="LinkedIn" width="32">
        </a>
        <a href="https://www.youtube.com/NutriCore" target="_blank">
            <img src="/student013/shop/assets/icons/youtube.svg" alt="YouTube" width="32">
        </a>
    </div>

    <div class="politics">
        <a href="#">Política de privacidad</a>
    </div>
    <div class="terminos">
        <a href="#">Términos de uso</a>
    </div>
    <div class="contacto">
        <a href="#">Contacto</a>
    </div>

    <p>&copy; 2025 NutriCore. Todos los derechos reservados.</p>
</footer>

<!-- SCRIPTS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="/student013/shop/js/accesibilidad.js"></script>

</body>

</html>