<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    echo "Acceso denegado";
    exit;
}

$logDir = $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/logs/';
$date = $_GET['date'] ?? date("Y-m-d");
$type = $_GET['type'] ?? '';
$search = $_GET['search'] ?? '';
$action = $_GET['action'] ?? '';

$logFile = $logDir . $date . ".log";

// Descargar archivo
if ($action === "download" && file_exists($logFile)) {
    header("Content-Type: text/plain");
    header("Content-Disposition: attachment; filename=\"$date.log\"");
    readfile($logFile);
    exit;
}

// Borrar archivo
if ($action === "delete" && file_exists($logFile)) {
    unlink($logFile);
    echo "DELETED";
    exit;
}

// Mostrar contenido filtrado
if (!file_exists($logFile)) {
    echo "NO_LOG";
    exit;
}

$lines = file($logFile, FILE_IGNORE_NEW_LINES);

$result = [];

foreach ($lines as $line) {
    if ($type && strpos($line, $type) === false) continue;
    if ($search && stripos($line, $search) === false) continue;
    $result[] = $line;
}

echo implode("\n", $result);
