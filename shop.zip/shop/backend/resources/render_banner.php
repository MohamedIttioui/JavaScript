<?php require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php'; ?>
<?php
$sql = "SELECT title, subtitle, image_url, link_url 
        FROM 013_promotions 
        WHERE is_active = 1 
        ORDER BY sort_order ASC, promotion_id DESC";

$result = $conn->query($sql);
$slides_data = [];
$disabled = true;

if ($result && $result->num_rows > 0) {
  // Almacenamos los resultados en un array para procesarlos fuera del while
  while ($row = $result->fetch_assoc()) {
    $slides_data[] = $row;
  }
} else {
  $slides_data[] = [
    'title' => 'Bienvenido',
    'subtitle' => 'Tu viaje al fitness comienza aquí',
    'image_url' => 'https://via.placeholder.com/1200x480?text=Bienvenido+a+NutriCore',
    'link_url' => '#'
  ];
}
$conn->close();
?>

<div class="slides">
  <?php $i = 0;
  foreach ($slides_data as $slide): ?>
    <?php $active_class = ($i === 0) ? ' active' : ''; ?>
    <div class="slide<?php echo $active_class; ?>"
      style="background-image:url('<?php echo htmlspecialchars($slide['image_url']); ?>');">
      <div class="slide-inner">
        <h1><?php echo htmlspecialchars($slide['title']); ?></h1>
        <p><?php echo htmlspecialchars($slide['subtitle']); ?></p>
        <a href="<?= $disabled ? '#' : htmlspecialchars($slide['link_url']); ?>"
          class="cta <?= $disabled ? 'disabled' : '' ?>"
          <?= $disabled ? 'onclick="return false;"' : '' ?>>
          Ver ofertas
        </a>
      </div>
    </div>
  <?php $i++; endforeach; ?>
</div>

<button class="nav-btn left" aria-label="Anterior">
  <img src="./assets/icons/left.svg" alt="Anterior" width="24">
</button>
<button class="nav-btn right" aria-label="Siguiente">
  <img src="./assets/icons/right.svg" alt="Siguiente" width="24">
</button>

<div class="dots">
  <?php for ($j = 0; $j < count($slides_data); $j++): ?>
    <?php $active_dot_class = ($j === 0) ? ' active' : ''; ?>
    <button class="dot<?php echo $active_dot_class; ?>" data-slide="<?php echo $j; ?>"></button>
  <?php endfor; ?>
</div>