<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$customer_id = intval($_SESSION['customer_id'] ?? 0);
$guest_cookie = $_COOKIE['guest_id'] ?? null;

// Solo uno activo
$guest_id = $customer_id > 0 ? null : ($guest_cookie ? $guest_cookie : null);

// Datos del cliente (solo si está logueado)
$nombre = $email = $direccion = $ciudad = $cp = $phone = "";

if ($customer_id > 0) {
  $sql_customer = "SELECT CONCAT(first_name, ' ', last_name) AS name, email, phone, address, city, zip_code, country
        FROM 013_customers
        WHERE customer_id = $customer_id
    ";
  $result_customer = $conn->query($sql_customer);
  if ($result_customer && $result_customer->num_rows > 0) {
    $customer = $result_customer->fetch_assoc();
    $nombre    = htmlspecialchars($customer['name']);
    $email     = htmlspecialchars($customer['email']);
    $phone     = htmlspecialchars($customer['phone']);
    $direccion = htmlspecialchars($customer['address']);
    $ciudad    = htmlspecialchars($customer['city']);
    $cp        = htmlspecialchars($customer['zip_code']);
  }
}

// Obtener carrito
$subtotal = 0;
$shipping = 4.99;
$items_html = "<p>Tu carrito está vacío.</p>";

if ($customer_id > 0) {
  $sql_cart = "SELECT 
            sc.quantity,
            p.name,
            p.price AS product_price,
            v.price AS variant_price
        FROM 013_shopping_cart sc
        JOIN 013_products p ON sc.product_id = p.product_id
        LEFT JOIN 013_product_variants v ON sc.variant_id = v.variant_id
        WHERE sc.customer_id = $customer_id
    ";
} elseif ($guest_id !== null) {
  $sql_cart = "SELECT 
            sc.quantity,
            p.name,
            p.price AS product_price,
            v.price AS variant_price
        FROM 013_shopping_cart sc
        JOIN 013_products p ON sc.product_id = p.product_id
        LEFT JOIN 013_product_variants v ON sc.variant_id = v.variant_id
        WHERE sc.guest_id = '$guest_id'
    ";
} else {
  $sql_cart = null;
}

if ($sql_cart) {
  $result_cart = $conn->query($sql_cart);

  if ($result_cart && $result_cart->num_rows > 0) {
    $items_html = "";
    while ($item = $result_cart->fetch_assoc()) {

      // PRECIO CORRECTO: variante si existe, si no precio base
      $price = $item['variant_price'] !== null
        ? (float)$item['variant_price']
        : (float)$item['product_price'];

      $item_total = $price * $item['quantity'];
      $subtotal += $item_total;

      $items_html .= "<p><strong>{$item['quantity']}x</strong> {$item['name']} 
                (Precio Unidad: €" . number_format($price, 2) . ")</p>";
    }
  }
}

$total = $subtotal + $shipping;

$conn->close();
?>

<main class="checkout-container">
  <h1 class="section-title">Finalizar Compra</h1>

  <div class="checkout-layout">
    <section class="checkout-form">
      <h2>Datos de Envío</h2>
      <form id="form-checkout">

        <div class="form-group">
          <label for="nombre">Nombre completo</label>
          <input type="text" id="nombre" value="<?= $nombre ?>" required>
        </div>

        <div class="form-group">
          <label for="email">Correo electrónico</label>
          <input type="email" id="email" value="<?= $email ?>" required>
        </div>

        <div class="form-group">
          <label for="phone">Teléfono</label>
          <input type="tel" id="phone" value="<?= $phone ?>" required>
        </div>

        <div class="form-group">
          <label for="direccion">Dirección</label>
          <input type="text" id="direccion" value="<?= $direccion ?>" required>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="ciudad">Ciudad</label>
            <input type="text" id="ciudad" value="<?= $ciudad ?>" required>
          </div>
          <div class="form-group">
            <label for="cp">Código Postal</label>
            <input type="text" id="cp" value="<?= $cp ?>" required>
          </div>
        </div>

        <h2>Método de Pago</h2>
        <div class="payment-methods">
          <label class="method"><input type="radio" name="payment" value="tarjeta" checked> Tarjeta de crédito</label>
          <label class="method"><input type="radio" name="payment" value="paypal"> PayPal</label>
          <label class="method"><input type="radio" name="payment" value="transferencia"> Transferencia bancaria</label>
        </div>

        <div class="form-group">
          <label for="comentarios">Comentarios adicionales</label>
          <textarea id="comentarios" rows="3" placeholder="Notas sobre tu pedido..."></textarea>
        </div>

        <div class="checkout-actions">
          <button type="submit" class="btn-primary">Realizar Pedido</button>
          <a href="carrito.html" class="btn-ghost">Volver al Carrito</a>
        </div>
      </form>
    </section>

    <aside class="order-summary">
      <h2>Resumen del Pedido</h2>
      <div class="summary-line"><span>Subtotal</span><span>€<?= number_format($subtotal, 2) ?></span></div>
      <div class="summary-line"><span>Envío</span><span>€<?= number_format($shipping, 2) ?></span></div>
      <div class="summary-total"><span>Total</span><span>€<?= number_format($total, 2) ?></span></div>
      <div class="summary-items"><?= $items_html ?></div>
    </aside>
  </div>
</main>