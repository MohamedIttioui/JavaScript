<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
header('Content-Type: application/json');

$sql = "SELECT year, month, total_orders, total_revenue FROM orders_per_month";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);