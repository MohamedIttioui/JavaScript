<?php require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php'; ?>
<!-- render_products.php -->
<?php
//  SECCIÓN 1: PRODUCTOS DESTACADOS
$sql = "SELECT product_id, `name`, price, format, `image`
        FROM `013_products`
        WHERE is_featured = 1
        ORDER BY product_id ASC
        LIMIT 8";

$result = $conn->query($sql);
$products_data = [];

$defaultImage = '/student013/shop/assets/img/protein.png';

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $products_data[] = $row;
  }
}
?>

<h1 class="section-title">Nuestros Productos</h1>

<div class="card-flex">
  <?php if (!empty($products_data)): ?>
    <?php foreach ($products_data as $row): ?>
      <?php
      $product_id = htmlspecialchars($row['product_id']);
      $name = htmlspecialchars($row['name']);
      $price = number_format($row['price'], 2);
      $format = htmlspecialchars($row['format'] ?? 'N/A');
      $image = htmlspecialchars($row['image'] ?? $defaultImage);
      ?>
      <div class="card" data-product-id="<?= $product_id ?>">
        <a
          href="/student013/shop/views/product-detalle.html?product_id=<?= $product_id ?>"
          aria-label="Ver detalles del producto <?= $name ?>">
          <img src="<?= $image ?>" alt="Imagen del producto <?= $name ?>">
        </a>

        <h4><?= $name ?></h4>
        <div class="price">€<?= $price ?></div>
        <div class="formato">Formato: <?= $format ?></div>

        <div class="card-actions">
          <input
            type="number"
            class="product-qty-input"
            value="1"
            min="1"
            id="qty-<?= $product_id ?>"
            aria-label="Cantidad del producto <?= $name ?>"
            aria-required="true">

          <button
            class="btn btn-primary add-to-cart"
            aria-label="Agregar <?= $name ?> al carrito"
            onclick="addToCart(<?= $product_id ?>, document.getElementById('qty-<?= $product_id ?>').value)">
            Agregar
          </button>

          <a
            href="./views/product-detalle.html?product_id=<?= $product_id ?>"
            class="btn btn-ghost"
            aria-label="Ver detalles del producto <?= $name ?>">
            Ver
          </a>
        </div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p class="info-message">No hay productos destacados disponibles en este momento.</p>
  <?php endif; ?>
</div>

<a href="#" id="up">Ver más</a>

<?php
$defaultImage = '/student013/shop/assets/img/protein.png';

//  SECCIÓN 2: PRODUCTOS IMPORTADOS
// Obtener productos importados (del partner)
$sql = "SELECT product_id, name, price, format, image
        FROM 013_products
        WHERE is_external = 1
        ORDER BY product_id DESC
        LIMIT 8";

$result = $conn->query($sql);
$imported = [];

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $imported[] = $row;
  }
}

$conn->close();
?>

<h1 class="section-title" style="margin-top: 20px;">Productos importados</h1>

<div class="card-flex">
  <?php if (!empty($imported)): ?>
    <?php foreach ($imported as $row): ?>
      <?php
      $product_id = htmlspecialchars($row['product_id']);
      $name = htmlspecialchars($row['name']);
      $price = number_format($row['price'], 2);
      $format = htmlspecialchars($row['format'] ?? 'N/A');
      $image = htmlspecialchars($row['image'] ?? $defaultImage);
      ?>
      <div class="card imported" data-product-id="<?= $product_id ?>">
        <a href="/student013/shop/views/product-detalle.html?product_id=<?= $product_id ?>">
          <img src="<?= $defaultImage ?>" alt="<?= $name ?>">
        </a>

        <h4><?= $name ?> <span class="tag-imported">Imported</span></h4>
        <div class="price">€<?= $price ?></div>
        <div class="formato">Formato: <?= $format ?></div>

        <div class="card-actions">
          <input type="number" class="product-qty-input" value="1" min="1" id="qty-<?= $product_id ?>">
          <button class="btn btn-primary add-to-cart"
            onclick="addToCart(<?= $product_id ?>, document.getElementById('qty-<?= $product_id ?>').value)">
            Agregar
          </button>
          <a href="./views/product-detalle.html?product_id=<?= $product_id ?>" class="btn btn-ghost">Ver</a>
        </div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p class="info-message">No hay productos importados disponibles.</p>
  <?php endif; ?>
</div>