<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/functions/cart_json_response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    cartJsonResponse(false, 'Método no permitido.');
}

// Leer JSON
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);
if (!$data) {
    cartJsonResponse(false, 'JSON inválido.');
}

// Identificar comprador
$customer_id = intval($_SESSION['customer_id'] ?? 0);
$guest_cookie = $_COOKIE['guest_id'] ?? null;
$guest_id = $customer_id > 0 ? null : ($guest_cookie ? $guest_cookie : null);

if ($customer_id === 0 && $guest_id === null) {
    cartJsonResponse(false, 'No se encontró un carrito activo.');
}

// Datos del checkout
$shipping_address = $conn->real_escape_string($data['shipping_address'] ?? '');
$payment_method = $conn->real_escape_string($data['payment_method'] ?? 'none');
$comments = $conn->real_escape_string($data['comments'] ?? '');

// Calcular subtotal
$subtotal = 0;

$sql = "SELECT 
        sc.quantity,
        p.price AS product_price,
        v.price AS variant_price
    FROM 013_shopping_cart sc
    JOIN 013_products p ON sc.product_id = p.product_id
    LEFT JOIN 013_product_variants v ON sc.variant_id = v.variant_id
    " . ($customer_id > 0
    ? "WHERE sc.customer_id = $customer_id"
    : "WHERE sc.guest_id = '$guest_id'"
);

$result = $conn->query($sql);
if (!$result) {
    cartJsonResponse(false, 'ERROR SQL CARRITO', ['sql_error' => $conn->error]);
}
if ($result->num_rows === 0) {
    cartJsonResponse(false, 'CARRITO VACÍO');
}

while ($row = $result->fetch_assoc()) {

    // PRECIO CORRECTO
    $price = $row['variant_price'] !== null
        ? (float)$row['variant_price']
        : (float)$row['product_price'];

    $subtotal += $price * $row['quantity'];
}

$shipping = 4.99;
$total = $subtotal + $shipping;
$status = 'pending';

// Crear número de orden
$order_number = 'NC-' . date('Y') . '-' . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);

// Crear orden
$sql_orders = "INSERT INTO 013_orders 
    (customer_id, guest_id, total, status, order_number, shipping_address, payment_method, notes)
    VALUES (
        " . ($customer_id > 0 ? $customer_id : "NULL") . ",
        " . ($guest_id !== null ? "'$guest_id'" : "NULL") . ",
        $total,
        '$status',
        '$order_number',
        '$shipping_address',
        '$payment_method',
        '$comments'
    )
";

if (!$conn->query($sql_orders)) {
    cartJsonResponse(false, 'ERROR INSERT ORDER', [
        'sql' => $sql_orders,
        'error' => $conn->error
    ]);
}

$order_id = $conn->insert_id;

// Insertar ítems con precio correcto y datos externos BLINDADOS
$sql_items = "INSERT INTO 013_order_items 
    (order_id, product_id, product_name, quantity, price, is_external, external_product_id, partner_id)
    SELECT
        $order_id,
        sc.product_id,
        p.name,
        sc.quantity,
        COALESCE(v.price, p.price) AS price,
        CASE WHEN p.is_external = 1 THEN 1 ELSE 0 END AS is_external,
        CASE WHEN p.is_external = 1 THEN p.external_id ELSE NULL END AS external_product_id,
        CASE WHEN p.is_external = 1 THEN p.partner_id ELSE NULL END AS partner_id
    FROM 013_shopping_cart sc
    JOIN 013_products p ON sc.product_id = p.product_id
    LEFT JOIN 013_product_variants v ON sc.variant_id = v.variant_id
    " . ($customer_id > 0
    ? "WHERE sc.customer_id = $customer_id"
    : "WHERE sc.guest_id = '$guest_id'"
);

if (!$conn->query($sql_items)) {
    cartJsonResponse(false, 'ERROR INSERT ITEMS', [
        'sql' => $sql_items,
        'error' => $conn->error
    ]);
}

// Enviar pedido externo al partner
$send_url = "http://localhost/student013/shop/backend/api/me/send_cross_order.php?order_id=$order_id";

$ch = curl_init($send_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$error = curl_error($ch);
curl_close($ch);

// Guardar log
file_put_contents(
    $_SERVER['DOCUMENT_ROOT'] . "/student013/shop/backend/logs/external_orders.log",
    date("Y-m-d H:i:s") . " | Order $order_id | Response: $response | Error: $error\n",
    FILE_APPEND
);

// Vaciar carrito
if ($customer_id > 0) {
    $conn->query("DELETE FROM 013_shopping_cart WHERE customer_id = $customer_id");
} else {
    $conn->query("DELETE FROM 013_shopping_cart WHERE guest_id = '$guest_id'");
}

// Respuesta final
cartJsonResponse(true, 'Pedido creado con éxito.', [
    'order_id' => $order_id,
    'order_number' => $order_number,
    'redirect' => '/student013/shop/views/payment.html'
]);
