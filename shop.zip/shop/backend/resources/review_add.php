<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . "/student013/shop/backend/database/db_reviews/db_review_insert.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/student013/shop/backend/database/db_orders/db_order_has_product.php";
header("Content-Type: application/json");

if (!isset($_SESSION['user']) || $_SESSION['user']['type'] !== 'customer') {
  echo json_encode(["status" => "error", "message" => "Debes iniciar sesión"]);
  exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$product_id = (int)$data['product_id'];
$rating     = (int)$data['rating'];
$comment    = trim($data['comment']);

if ($product_id <= 0 || $rating < 1 || $rating > 5 || $comment === "") {
  echo json_encode(["status" => "error", "message" => "Datos inválidos"]);
  exit;
}

$customer_id = $_SESSION['user']['id'];

if (!customer_has_bought_product($customer_id, $product_id)) {
  echo json_encode(["status" => "error", "message" => "Solo puedes valorar productos comprados"]);
  exit;
}

if (insert_review($product_id, $customer_id, $rating, $comment)) {
  echo json_encode(["status" => "ok", "message" => "Review enviada. Pendiente de aprobación"]);
} else {
  echo json_encode(["status" => "error", "message" => "Error al guardar"]);
}
