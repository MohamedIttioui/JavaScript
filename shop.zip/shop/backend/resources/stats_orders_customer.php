<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
header('Content-Type: application/json');

$sql = "SELECT customer_id, customer_name, total_orders, total_spent FROM orders_per_customer";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data);