<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$response = [
    "success" => false,
    "products" => [],
    "message" => ""
];

$sql = "SELECT product_id, name, price, image, description FROM 013_products ORDER BY created_at DESC LIMIT 50";
$result = $conn->query($sql);

if (!$result) {
    $response["message"] = "Error en la consulta: " . $conn->error;
    echo json_encode($response);
    exit;
}

$imagePath = "/student013/shop/assets/img/";
$defaultImage = "/student013/shop/assets/img/protein.png";

while ($row = $result->fetch_assoc()) {

    $img = trim($row['image']);

    if ($img !== "" && file_exists($_SERVER['DOCUMENT_ROOT'] . $imagePath . $img)) {
        $row['image'] = "http://localhost" . $imagePath . $img;
    } else {
        $row['image'] = "http://localhost" . $defaultImage;
    }

    $response["products"][] = $row;
}

$response["success"] = true;

echo json_encode($response);
$conn->close();
