<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php'; ?>
<?php
header('Content-Type: application/json');
$response = ['success' => false, 'categories' => [], 'message' => ''];

// Consulta para obtener categorías principales
$sql_main = "SELECT category_id, name FROM 013_categories ORDER BY category_id ASC";
$result_main = $conn->query($sql_main);

if (!$result_main) {
  $response['message'] = "Error al consultar categorías: " . $conn->error;
  echo json_encode($response);
  $conn->close();
  exit;
}
$categories = [];

while ($category = $result_main->fetch_assoc()) {
  $category_id = intval($category['category_id']);

  // Consulta para obtener submenús (productos relacionados)
  $sql_sub = "SELECT p.product_id, p.name 
                FROM 013_products p
                JOIN 013_product_categories pc ON p.product_id = pc.product_id
                WHERE pc.category_id = {$category_id}
                ORDER BY p.created_at DESC
                LIMIT 4";

  $result_sub = $conn->query($sql_sub);

  if (!$result_sub) {
    $response['message'] = "Error al consultar submenús: " . $conn->error;
    echo json_encode($response);
    $result_main->free();
    $conn->close();
    exit;
  }

  $sub_items = [];
  while ($sub_row = $result_sub->fetch_assoc()) {
    $sub_items[] = $sub_row;
  }
  $result_sub->free();

  // Añadir los sub-items a la categoría principal
  $category['submenus'] = $sub_items;
  $categories[] = $category;
}

$result_main->free();
$response['success'] = true;
$response['categories'] = $categories;

$conn->close();
echo json_encode($response);
?>