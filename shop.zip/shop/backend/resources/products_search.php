<link rel="stylesheet" href="/student013/shop/backend/css/products.css">
<?php
session_start();
$userType = $_SESSION['user_type'] ?? 'guest';

require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/functions/show_products.php';

// Recibir el término de búsqueda
$searchItem = $_GET['product_id'] ?? '';
$searchItem = $conn->real_escape_string($searchItem);

show_products($conn, $userType, $searchItem);

$conn->close();
?>