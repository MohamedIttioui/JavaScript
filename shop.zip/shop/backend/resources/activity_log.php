<?php
function register_event($message)
{
    $logDir = $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/logs/';

    if (!file_exists($logDir)) {
        mkdir($logDir, 0777, true);
    }

    $logFile = $logDir . date("Y-m-d") . ".log";

    $entry = "[" . date("Y-m-d H:i:s") . "] " . $message . "\n";

    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}
