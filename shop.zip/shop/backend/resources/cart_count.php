<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
header('Content-Type: application/json');

$customer_id = $_SESSION['customer_id'] ?? null;
$guest_id = $_COOKIE['guest_id'] ?? null;

if ($customer_id) {
  $sql = "SELECT SUM(quantity) as count FROM 013_shopping_cart WHERE customer_id=" . intval($customer_id);
} elseif ($guest_id) {
  $sql = "SELECT SUM(quantity) as count FROM 013_shopping_cart WHERE guest_id='" . $conn->real_escape_string($guest_id) . "'";
} else {
  echo json_encode(['count' => 0]);
  exit;
}

$result = $conn->query($sql);
$count = ($result && $row = $result->fetch_assoc()) ? intval($row['count']) : 0;
$conn->close();

echo json_encode(['count' => $count]);
?>