<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

if (!isset($_GET['product_id'])) {
  echo "<p>No se especificó producto.</p>";
  exit;
}

$product_id = intval($_GET['product_id']);
$customer_id = $_SESSION['customer_id'] ?? null;
$guest_id = $_COOKIE['guest_id'] ?? null;

/*1. Construir condiciones dinámicas para evitar SQL inválido */
function buildConditions($customer_id, $guest_id, $conn)
{
  $conditions = [];

  if ($customer_id) {
    $conditions[] = "o.customer_id = " . intval($customer_id);
  }

  if ($guest_id) {
    $guest_id_safe = $conn->real_escape_string($guest_id);
    $conditions[] = "o.guest_id = '$guest_id_safe'";
  }

  return $conditions;
}

/* 2. ¿Ha comprado este producto? */
$conditions = buildConditions($customer_id, $guest_id, $conn);

if (empty($conditions)) {
  $has_bought = false;
} else {
  $where = implode(" OR ", $conditions);

  $sqlBought = "SELECT oi.order_id
        FROM 013_order_items oi
        JOIN 013_orders o ON oi.order_id = o.order_id
        WHERE oi.product_id = $product_id
        AND ($where)
        LIMIT 1
    ";

  $resBought = $conn->query($sqlBought);
  $has_bought = $resBought && $resBought->num_rows > 0;
}

/* 3. ¿Ya dejó review?*/
$conditions = [];

if ($customer_id) {
  $conditions[] = "customer_id = " . intval($customer_id);
}

if ($guest_id) {
  $guest_id_safe = $conn->real_escape_string($guest_id);
  $conditions[] = "guest_id = '$guest_id_safe'";
}

if (empty($conditions)) {
  $has_reviewed = false;
} else {
  $where = implode(" OR ", $conditions);

  $sqlReviewed = "SELECT review_id
        FROM 013_reviews
        WHERE product_id = $product_id
        AND ($where)
        LIMIT 1
    ";

  $resReviewed = $conn->query($sqlReviewed);
  $has_reviewed = $resReviewed && $resReviewed->num_rows > 0;
}

/* 4. Obtener reviews*/
$sql = "SELECT rating, comment, created_at 
        FROM 013_reviews 
        WHERE product_id = $product_id
        ORDER BY created_at DESC";

$res = $conn->query($sql);

/* 5. Obtener estadísticas */
$sql2 = "SELECT AVG(rating) AS avg_rating, COUNT(*) AS total_reviews
         FROM 013_reviews
         WHERE product_id = $product_id";

$stats = $conn->query($sql2)->fetch_assoc();

$avg = $stats['avg_rating'] ? number_format($stats['avg_rating'], 1) : 0;
$total = $stats['total_reviews'] ?? 0;
?>

<!--RESUMEN DE REVIEWS-->
<div class="reviews-summary">
  <h3>Opiniones</h3>
  <p>
    ⭐ <?= $avg ?> / 5 (<?= $total ?> reviews)
  </p>
</div>

<!-- LISTA DE REVIEWS -->
<div class="reviews-list">
  <?php
  if ($res->num_rows === 0) {
    echo "<p>No hay reviews todavía.</p>";
  } else {
    while ($row = $res->fetch_assoc()) {
      echo "
        <div class='review'>
            <div class='stars'>" . str_repeat("⭐", $row['rating']) . "</div>
            <p>{$row['comment']}</p>
            <small>{$row['created_at']}</small>
        </div>
        ";
    }
  }
  ?>
</div>

<div class="review-form">
  <h3>Deja tu review</h3>

  <?php if (!$customer_id && !$guest_id): ?>
    <p style="color:red;">Debes iniciar sesión para dejar una review.</p>

  <?php elseif (!$has_bought): ?>
    <p style="color:red;">Solo puedes valorar productos que has comprado.</p>

  <?php elseif ($has_reviewed): ?>
    <p style="color:red;">Ya has valorado este producto.</p>

  <?php else: ?>
    <label>Valoración:</label>
    <select id='review-rating'>
      <option value='5'>⭐⭐⭐⭐⭐</option>
      <option value='4'>⭐⭐⭐⭐</option>
      <option value='3'>⭐⭐⭐</option>
      <option value='2'>⭐⭐</option>
      <option value='1'>⭐</option>
    </select>

    <label>Comentario:</label>
    <textarea id='review-comment' placeholder='Escribe tu opinión...'></textarea>

    <button onclick="submitReview(<?= $product_id ?>)">Enviar review</button>

    <div id="review-message"></div>
  <?php endif; ?>
</div>