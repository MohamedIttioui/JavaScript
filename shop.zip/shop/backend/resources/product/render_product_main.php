<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$defaultImage = '/student013/shop/assets/img/protein.png';
$product_id = intval($_GET['product_id']);
$sql = "SELECT product_id, name, description, format, flavor, price, stock, image, features
    FROM 013_products
    WHERE product_id = $product_id
    LIMIT 1
";
$res = $conn->query($sql);
if (!$res || $res->num_rows === 0) {
  echo "<p>Producto no encontrado.</p>";
  return;
}
$product = $res->fetch_assoc();

$name   = htmlspecialchars($product['name']);
$desc   = nl2br(htmlspecialchars($product['description']));
$image  = htmlspecialchars($product['image']) ?? $defaultImage;
$stock  = (int)$product['stock'];
$basePrice = (float)$product['price'];

$features = array_filter(array_map('trim', explode(";", $product['features'] ?? "")));

// Variantes
$variants = [];
$qVar = $conn->query("
    SELECT variant_id, label, price, stock
    FROM 013_product_variants
    WHERE product_id = {$product['product_id']}
");
if ($qVar && $qVar->num_rows > 0) {
  while ($row = $qVar->fetch_assoc()) {
    $variants[] = $row;
  }
}

// Sabores
$flavors = [];
$qFlav = $conn->query("
    SELECT flavor
    FROM 013_product_flavors
    WHERE product_id = {$product['product_id']}
");
if ($qFlav && $qFlav->num_rows > 0) {
  while ($row = $qFlav->fetch_assoc()) {
    $flavors[] = $row['flavor'];
  }
}

// Fallback si no hay variantes/sabores
if (empty($variants)) {
  $variants[] = [
    'variant_id' => 0,
    'label'      => $product['format'] ?: 'Único formato',
    'price'      => $basePrice,
    'stock'      => $stock
  ];
}
if (empty($flavors) && !empty($product['flavor']) && strtolower($product['flavor']) !== 'n/a') {
  $flavors = array_map('trim', explode(",", $product['flavor']));
}
?>

<div class="product-gallery">
  <img src="<?= $image ?>" alt="Imagen principal del producto <?= $name ?>" class="main-image">

  <div class="small-images flex gap-2 mt-2.5 overflow-x-auto">
    <img src="<?= $image ?>" alt="Vista del producto <?= $name ?> - imagen 1">
    <img src="<?= $image ?>" alt="Vista del producto <?= $name ?> - imagen 2">
    <img src="<?= $image ?>" alt="Vista del producto <?= $name ?> - imagen 3">
    <img src="<?= $image ?>" alt="Vista del producto <?= $name ?> - imagen 4">
  </div>
</div>

<div class="product-details">
  <h1 class="product-title"><?= $name ?></h1>
  <p class="product-desc"><?= $desc ?></p>

  <div class="selectors">

    <!-- FORMATO -->
    <div class="select-group">
      <label for="formato">Formato:</label>
      <div class="format-options">
        <?php $first = true;
        foreach ($variants as $v): ?>
          <?php
          $label = htmlspecialchars($v['label']);
          $price = (float)$v['price'];
          $vStock = (int)$v['stock'];
          ?>
          <button
            class="format-btn <?= $first ? 'active' : '' ?>"
            aria-label="Seleccionar formato <?= $label ?>"
            aria-pressed="<?= $first ? 'true' : 'false' ?>"
            data-price="<?= $price ?>"
            data-stock="<?= $vStock ?>"
            data-variant-id="<?= $v['variant_id'] ?>"
            data-format="<?= $label ?>">
            <?= $label ?>
          </button>
        <?php $first = false;
        endforeach; ?>
      </div>
    </div>

    <!-- SABOR -->
    <div class="select-group">
      <label for="sabor">Sabor:</label>
      <select id="sabor" aria-label="Seleccionar sabor del producto">
        <?php if (!empty($flavors)): ?>
          <?php foreach ($flavors as $f): ?>
            <option value="<?= htmlspecialchars($f) ?>"><?= htmlspecialchars($f) ?></option>
          <?php endforeach; ?>
        <?php else: ?>
          <option value="">Sin sabor</option>
        <?php endif; ?>
      </select>
    </div>

  </div>

  <!-- PRECIO Y STOCK -->
  <div class="product-info">
    <span class="price" id="product-price" aria-live="polite">
      <?= number_format($variants[0]['price'], 2) ?>€
    </span>

    <div class="stock" aria-live="polite">
      <?= $variants[0]['stock'] > 0 ? "En stock ✅" : "Sin stock ❌" ?>
    </div>
  </div>

  <!-- ACCIONES -->
  <div class="actions">
    <div class="quantity">
      <label for="cantidad">Cantidad:</label>
      <input type="number" id="cantidad" min="1" value="1" aria-label="Cantidad del producto <?= $name ?>" aria-required="true">
    </div>

    <div class="btn-group">
      <button class="btn-primary" aria-label="Agregar <?= $name ?> al carrito" onclick="addToCart(<?= $product['product_id'] ?>)">
        Agregar al carrito
      </button>

      <button class="btn-ghost" aria-label="Añadir <?= $name ?> a favoritos">Añadir a favoritos</button>
    </div>
  </div>

  <!-- CARACTERÍSTICAS -->
  <div class="features">
    <h3>Características</h3>
    <ul>
      <?php foreach ($features as $f): ?>
        <li><?= htmlspecialchars($f) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
</div>