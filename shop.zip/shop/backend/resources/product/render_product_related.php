<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$product_id = intval($_GET['product_id'] ?? 0);

$sql = "
    SELECT product_id, name, price, image
    FROM 013_products
    WHERE product_id != $product_id
    ORDER BY RAND()
    LIMIT 4
";
$res = $conn->query($sql);
?>

<h2 class="section-title">Productos Relacionados</h2>
<div class="card-grid">
  <?php while ($row = $res->fetch_assoc()): ?>
    <div class="card">
      <a href="/student013/shop/views/product-detalle.html?product_id=<?= $row['product_id'] ?>">
        <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
      </a>
      <h4><?= htmlspecialchars($row['name']) ?></h4>
      <span class="price">€<?= number_format($row['price'], 2) ?></span>
    </div>
  <?php endwhile; ?>
</div>