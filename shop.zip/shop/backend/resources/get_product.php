<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$response = [
    "success" => false,
    "product" => null,
    "message" => ""
];

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    $response["message"] = "ID inválido";
    echo json_encode($response);
    exit;
}

$sql = "SELECT * FROM 013_products WHERE product_id = $id LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows === 1) {
    $product = $result->fetch_assoc();

    // Construir ruta completa de imagen
    $imagePath = "/student013/shop/assets/img/";
    $defaultImage = "/student013/shop/assets/img/protein.png";

    if (!empty($product['image']) && file_exists($_SERVER['DOCUMENT_ROOT'] . $imagePath . $product['image'])) {
        $product['image'] = "http://localhost" . $imagePath . $product['image'];
    } else {
        $product['image'] = "http://localhost" . $defaultImage;
    }

    $response["success"] = true;
    $response["product"] = $product;
} else {
    $response["message"] = "Producto no encontrado";
}

echo json_encode($response);
$conn->close();
