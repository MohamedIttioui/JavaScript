<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
header('Content-Type: application/json');

$sql = "SELECT product_id, product_name, total_units_sold, total_revenue FROM orders_per_product";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);