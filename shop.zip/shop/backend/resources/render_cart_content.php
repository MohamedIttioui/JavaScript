<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

// Identificar usuario
$customer_id = $_SESSION['customer_id'] ?? null;
$guest_id = $_COOKIE['guest_id'] ?? null;

// Variables iniciales
$defaultImage = "/student013/shop/assets/img/whey_protein.jpg";
$subtotal = 0.00;
$shipping_cost = 4.99;
$cart_items = [];
$cart_is_empty = true;

// Consulta carrito
if ($customer_id || $guest_id) {

  $where = $customer_id
    ? "sc.customer_id = $customer_id"
    : "sc.guest_id = '$guest_id'";

  $sql = "SELECT 
            sc.shopping_cart_id,
            sc.product_id,
            sc.variant_id,
            sc.flavor AS selected_flavor,
            sc.quantity,

            p.name AS product_name,
            p.image AS product_image,
            p.price AS product_price,   -- 🔥 precio base del producto

            v.label AS variant_label,
            v.price AS variant_price
        FROM 013_shopping_cart sc
        JOIN 013_products p ON sc.product_id = p.product_id
        LEFT JOIN 013_product_variants v ON sc.variant_id = v.variant_id
        WHERE $where
        ORDER BY sc.shopping_cart_id DESC
    ";

  $result = $conn->query($sql);

  if ($result && $result->num_rows > 0) {
    $cart_is_empty = false;

    while ($row = $result->fetch_assoc()) {

      $quantity = (int)$row['quantity'];

      // 🔥 PRECIO CORRECTO: variante si existe, si no precio base
      $price = $row['variant_price'] !== null
        ? (float)$row['variant_price']
        : (float)$row['product_price'];

      $item_total = $price * $quantity;
      $subtotal += $item_total;

      $cart_items[] = [
        'id' => $row['shopping_cart_id'],
        'product_id' => (int)$row['product_id'],
        'name' => htmlspecialchars($row['product_name']),
        'quantity' => $quantity,
        'price_unit' => number_format($price, 2),
        'total_item' => number_format($item_total, 2),
        'image' => $row['product_image'] ? htmlspecialchars($row['product_image']) : $defaultImage,

        // PROFESIONAL: ocultar si no existe
        'format' => $row['variant_label'] ? htmlspecialchars($row['variant_label']) : null,
        'flavor' => $row['selected_flavor'] ? htmlspecialchars($row['selected_flavor']) : null,
      ];
    }
  }
}

$total = $subtotal + $shipping_cost;
$conn->close();
?>

<div class="cart-items">
  <?php if ($cart_is_empty): ?>
    <p class="empty-cart-message">Tu carrito está vacío. ¡Añade productos desde la página principal!</p>
  <?php else: ?>
    <?php foreach ($cart_items as $item): ?>
      <div class="cart-item" data-cart-id="<?= $item['id'] ?>">

        <a
          href="/student013/shop/views/product-detalle.html?product_id=<?= $item['product_id'] ?>"
          aria-label="Ver detalles del producto <?= $item['name'] ?>">
          <img src="<?= $item['image'] ?>" alt="Imagen del producto <?= $item['name'] ?>">
        </a>

        <div class="item-info">
          <h3><?= $item['name'] ?></h3>

          <?php if ($item['format']): ?>
            <p class="variant">Formato: <?= $item['format'] ?></p>
          <?php endif; ?>

          <?php if ($item['flavor']): ?>
            <p class="flavor">Sabor: <?= $item['flavor'] ?></p>
          <?php endif; ?>

          <p>Precio Unitario: €<?= $item['price_unit'] ?></p>

          <div class="quantity">
            <label for="qty<?= $item['id'] ?>">Cantidad:</label>
            <input
              type="number"
              id="qty<?= $item['id'] ?>"
              value="<?= $item['quantity'] ?>"
              min="1"
              aria-label="Cantidad del producto <?= $item['name'] ?>"
              aria-required="true"
              autocomplete="off"
              onchange="updateCartItem(<?= $item['id'] ?>, this.value)">
          </div>
        </div>

        <div class="item-price" aria-live="polite">€<?= $item['total_item'] ?></div>

        <button
          onclick="removeCartItem(<?= $item['id'] ?>)"
          class="remove-btn icon-btn"
          aria-label="Eliminar <?= $item['name'] ?> del carrito">
        </button>

      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<aside class="cart-summary">
  <h2>Resumen del pedido</h2>

  <div class="summary-line">
    <span>Subtotal</span>
    <span id="subtotal-display" aria-live="polite">€<?= number_format($subtotal, 2) ?></span>
  </div>

  <div class="summary-line">
    <span>Envío</span>
    <span id="shipping-display" aria-live="polite">€<?= number_format($shipping_cost, 2) ?></span>
  </div>

  <div class="summary-total">
    <span>Total</span>
    <span id="total-display" aria-live="polite">€<?= number_format($total, 2) ?></span>
  </div>

  <div class="cart-actions">
    <button class="btn-primary" aria-label="Ir al checkout" <?= $subtotal > 0 ? '' : 'disabled' ?>>Finalizar compra</button>
    <button class="btn-ghost" aria-label="Volver a la tienda">Seguir comprando</button>
  </div>
</aside>