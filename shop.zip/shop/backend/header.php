<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="/student013/shop/assets/img/logo_transparenteRecortado.png">
    <link rel="stylesheet" href="/student013/shop/css/common.css">
    <link rel="stylesheet" href="/student013/shop/backend/css/external.css">
    <link rel="stylesheet" href="/student013/shop/css/accesibilidad.css">
    <title>NutriCore</title>
</head>

<body>
    <!-- BOTÓN DE ACCESIBILIDAD -->
    <button id="btn-accesibilidad" aria-label="Abrir menú de accesibilidad">
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="currentColor"
            aria-hidden="true">
            <path d="M12 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 12 2zm7 7h-6v13h-2V14H9v8H7V9H5V7h14v2z" />
        </svg>
    </button>

    <!-- MENÚ DE ACCESIBILIDAD -->
    <div id="accesibilidad-menu" role="region" aria-label="Menú de accesibilidad">
        <h3>Accesibilidad</h3>

        <button class="contraste" data-mode="grayscale">Escala de grises</button>
        <button class="contraste" data-mode="dark">Contraste oscuro</button>
        <button class="contraste" data-mode="light">Contraste claro</button>
        <button class="contraste" data-mode="saturacion-alta">Saturación alta</button>
        <button class="contraste" data-mode="saturacion-baja">Saturación baja</button>

        <hr>

        <button id="font-plus">Aumentar letra</button>
        <button id="font-minus">Reducir letra</button>

        <button id="line-height-plus">Más interlineado</button>
        <button id="line-height-minus">Menos interlineado</button>

        <button id="word-spacing-plus">Más espacio entre palabras</button>
        <button id="word-spacing-minus">Menos espacio entre palabras</button>

        <button id="letter-spacing-plus">Más espacio entre letras</button>
        <button id="letter-spacing-minus">Menos espacio entre letras</button>

        <hr>

        <button id="reset-accesibilidad">Resetear</button>
    </div>

    <?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $userType = $_SESSION['user_type'] ?? 'guest';
    $userEmail = $_SESSION['user_email'] ?? '';
    ?>

    <header class="header" role="banner">
        <button class="menu-icon" aria-label="Abrir menú" role="button">
            <img src="/student013/shop/assets/icons/menu.svg" alt="Abrir menú" width="24">
        </button>

        <a href="/student013/shop">
            <img src="/student013/shop/assets/img/logo_transparenteRecortado.png" alt="NutriCore" class="logo">
        </a>

        <?php if ($userType === 'admin'): ?>
            <div class="header-icons">

                <a href="/student013/shop/index.html" class="icon-btn home-btn">
                    <img src="/student013/shop/assets/icons/home.svg" alt="Inicio" width="24">
                    <span>Home</span>
                </a>

                <div class="menu-admin">

                    <div class="menu-item">
                        <a href="/student013/shop/backend/forms/products/products_list.php" class="icon-btn">
                            <img src="/student013/shop/assets/icons/products.svg" alt="Productos" width="24">
                            <span class="menu-text">Products</span>
                        </a>
                        <div class="submenu">
                            <a href="/student013/shop/backend/forms/products/product_select.php">Select</a>
                            <a href="/student013/shop/backend/forms/products/product_insert.php">Insert</a>
                            <a href="/student013/shop/backend/forms/products/product_update.php">Update</a>
                            <a href="/student013/shop/backend/forms/products/product_delete.php">Delete</a>
                        </div>
                    </div>

                    <div class="menu-item">
                        <a href="/student013/shop/backend/forms/customers/customers_list.php" class="icon-btn">
                            <img src="/student013/shop/assets/icons/customers.svg" alt="Clientes" width="24">
                            <span class="menu-text">Customers</span>
                        </a>
                        <div class="submenu">
                            <a href="/student013/shop/backend/forms/customers/customer_select.php">Select</a>
                            <a href="/student013/shop/backend/forms/customers/customer_insert.php">Insert</a>
                            <a href="/student013/shop/backend/forms/customers/customer_update.php">Update</a>
                            <a href="/student013/shop/backend/forms/customers/customer_delete.php">Delete</a>
                        </div>
                    </div>

                    <div class="menu-item">
                        <a href="/student013/shop/backend/forms/orders/orders_list.php" class="icon-btn">
                            <img src="/student013/shop/assets/icons/orders.svg" alt="Pedidos" width="24">
                            <span class="menu-text">Orders</span>
                        </a>
                        <div class="submenu">
                            <a href="/student013/shop/backend/forms/orders/order_select.php">Select</a>
                            <a href="/student013/shop/backend/forms/orders/order_insert.php">Insert</a>
                            <a href="/student013/shop/backend/forms/orders/order_update.php">Update</a>
                            <a href="/student013/shop/backend/forms/orders/order_delete.php">Delete</a>
                        </div>
                    </div>

                </div>

                <div class="user-menu">
                    <button class="icon-btn user-btn">
                        <img src="/student013/shop/assets/icons/user-admin.svg" alt="Admin" width="24">
                        <span><?= isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Admin' ?></span>
                    </button>
                    <div class="user-dropdown admin">
                        <a href="/student013/shop/backend/database/db_logout.php">Logout</a>
                        <a href="/student013/shop/views/logs.html">See Logs</a>
                        <a href="/student013/shop/views/admin-stats.html">Admin Stats</a>
                        <a href="/student013/shop/backend/forms/orders/partner_billing.php">Partner Billing</a>
                        <a href="/student013/shop/backend/forms/orders/external_orders_list.php">External Orders</a>
                        <a href="/student013/shop/backend/forms/orders/external_orders_log.php">External Orders Logs</a>
                        <a href="http://localhost:5173" target="_blank">React App</a>
                    </div>
                </div>

            </div>

        <?php else: ?>

            <div class="header-icons">

                <div class="search-container">
                    <input type="search" id="search-input" class="search-input" placeholder="Buscar..."
                        aria-label="Buscar productos" autocomplete="off" onkeyup="searchProducts(this.value)">
                    <button class="icon-btn search-btn">
                        <img src="/student013/shop/assets/icons/search.svg" alt="Buscar" width="24">
                        <span>Search</span>
                    </button>
                </div>

                <a href="/student013/shop/index.html" class="icon-btn home-btn">
                    <img src="/student013/shop/assets/icons/home.svg" alt="Inicio" width="24">
                    <span>Home</span>
                </a>
                <!-- <a href="/student013/shop/backend/forms/orders/orders_list_guest.php">Mis pedidos (Invitado)</a> -->

                <div class="user-menu">
                    <button class="icon-btn user-btn">
                        <img src="/student013/shop/assets/icons/user.svg" alt="Usuario" width="24">
                        <span><?= isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Usuario' ?></span>
                    </button>

                    <div class="user-dropdown customer">
                        <?php if ($userType === 'guest'): ?>
                            <a href="/student013/shop/backend/forms/form_login.php" class="btn-log">Login</a>
                            <a href="/student013/shop/backend/forms/customers/customer_insert.php" class="btn-reg">Register</a>
                        <?php else: ?>
                            <a href="/student013/shop/backend/database/db_customers/db_customer_select.php">My account</a>
                            <a href="/student013/shop/backend/database/db_logout.php">Logout</a>
                            <a href="/student013/shop/backend/forms/orders/orders_list_customer.php">My orders</a>
                            <a href="/student013/shop/backend/riviews.php">Reviews</a>
                        <?php endif; ?>
                    </div>
                </div>

                <a href="/student013/shop/views/carrito.html" class="icon-btn cart-btn">
                    <img src="/student013/shop/assets/icons/cart.svg" alt="Carrito" width="24">
                    <span>Carrito</span>
                    <span id="cart-count">0</span>
                </a>

            </div>

        <?php endif; ?>
    </header>

    <div class="products-flex" id="products-container" style="margin-top: 20px;"></div>