<?php /* require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php'; */ ?>
<?php include $_SERVER['DOCUMENT_ROOT'] .  '/student013/shop/backend/forms/products/products_list.php';?>
<?php /* require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; */ ?>