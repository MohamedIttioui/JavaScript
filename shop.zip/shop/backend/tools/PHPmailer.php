<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/PHPMailer/src/Exception.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/PHPMailer/src/PHPMailer.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$contenido = '
<div style="font-family: Arial, Helvetica, sans-serif; max-width:600px; margin:auto; padding:20px; border:1px solid #e5e5e5; border-radius:10px; background:#ffffff; color:#333;">
    
    <h2 style="color:#1a73e8; margin-top:0; text-align:center;">
        Práctica PHPMailer – Envío de correo
    </h2>

    <p>Buenos días, Enrique:</p>

    <p>
        Te envío este correo como parte de la práctica de <strong>PHPMailer</strong>.  
        El objetivo es comprobar el correcto funcionamiento del envío mediante SMTP y la maquetación básica en HTML.
    </p>

    <p>
        Si el mensaje se visualiza correctamente, significa que la configuración ha sido realizada con éxito.
    </p>

    <div style="background:#f1f6ff; padding:15px; border-left:4px solid #1a73e8; border-radius:5px; margin:20px 0;">
        <p style="margin:0;">
            <strong>Detalles de la práctica:</strong><br>
            • Alumno: <em>Mohamed Ittioui</em><br>
            • Fecha de envío: <em>' . date("d/m/Y") . '</em><br>
            • Herramienta utilizada: PHPMailer + SMTP
        </p>
    </div>

    <p>
        Eso ha sido todo.
    </p>

    <p style="margin-top:30px;">
        Atentamente,<br>
        <strong>Mohamed Ittioui</strong>
    </p>

</div>
';
try {
  $mail = new PHPMailer(true);

  // Codificación de caracteres
  $mail->CharSet = 'UTF-8';
  $mail->Encoding = 'base64';

  // Configuración SMTP
  $mail->isSMTP();
  $mail->SMTPAuth = true;
  $mail->Host = "smtp.remotehost.es";
  $mail->Port = 587;
  $mail->Username = "no-reply@remotehost.es";
  $mail->Password = "Justfortesting26#";
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

  // Remitente y destinatario
  $mail->setFrom('no-reply@remotehost.es', 'RemoteHost');
  $mail->addAddress('profesor@dominio.com', 'Profesor');

  // Contenido del correo
  $mail->isHTML(true);
  $mail->Subject = 'Práctica PHPMailer – prueba de envio de correo con PHPMailer';
  $mail->Body = $contenido;
  $mail->AltBody = 'Hola profesor';

  // Envío
  $mail->send();
  echo "Correo enviado correctamente";
} catch (Exception $e) {
  echo "Error al enviar el correo: " . $mail->ErrorInfo;
}
