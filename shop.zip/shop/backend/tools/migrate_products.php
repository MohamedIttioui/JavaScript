<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

echo "<h2>Migración de productos a variantes y sabores</h2>";

$sql = "SELECT * FROM 013_products";
$res = $conn->query($sql);

if (!$res || $res->num_rows === 0) {
  die("No hay productos para migrar.");
}

while ($p = $res->fetch_assoc()) {

  $product_id = $p['product_id'];
  $format = trim($p['format']);
  $flavor = trim($p['flavor']);
  $price = $p['price'];
  $stock = $p['stock'];

  echo "<p><strong>Producto #$product_id:</strong> {$p['name']}</p>";

  /* -------------------------------
       1. MIGRAR FORMATO → VARIANTE
    --------------------------------*/
  if (!empty($format) && strtolower($format) !== "n/a") {

    // Comprobar si ya existe variante
    $checkVar = $conn->query("SELECT variant_id FROM 013_product_variants
            WHERE product_id = $product_id AND label = '$format'
        ");

    if ($checkVar->num_rows === 0) {
      $conn->query("INSERT INTO 013_product_variants (product_id, label, price, stock)
                VALUES ($product_id, '$format', $price, $stock)
            ");
      echo "→ Variante añadida: $format<br>";
    } else {
      echo "→ Variante ya existía: $format<br>";
    }
  }

  /* -------------------------------
       2. MIGRAR SABORES → FILAS
    --------------------------------*/
  if (!empty($flavor) && strtolower($flavor) !== "n/a") {

    // Separar por coma
    $flavors = array_map('trim', explode(",", $flavor));

    foreach ($flavors as $f) {
      if ($f === "") continue;

      // Comprobar si ya existe
      $checkFlavor = $conn->query("SELECT flavor_id FROM 013_product_flavors
                WHERE product_id = $product_id AND flavor = '$f'
            ");

      if ($checkFlavor->num_rows === 0) {
        $conn->query("INSERT INTO 013_product_flavors (product_id, flavor)
                    VALUES ($product_id, '$f')
                ");
        echo "→ Sabor añadido: $f<br>";
      } else {
        echo "→ Sabor ya existía: $f<br>";
      }
    }
  }

  echo "<hr>";
}

echo "<h3>Migración completada correctamente.</h3>";