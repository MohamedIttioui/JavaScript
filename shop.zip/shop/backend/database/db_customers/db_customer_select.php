<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

// Determinar el customer_id
$customer_id = 0;
if ($userType === 'customer' && !empty($_SESSION['customer_id']) && empty($_GET['customer_id'])) {
  $customer_id = intval($_SESSION['customer_id']);
} elseif (!empty($_GET['customer_id'])) {
  $customer_id = intval($_GET['customer_id']);
}
$canAccess = ($userType === 'admin') || $userType === 'customer' && !empty($_SESSION['customer_id']) && $_SESSION['customer_id'] == $customer_id;

// Obtener datos del cliente
$customer = null;
if ($customer_id > 0 && $canAccess) {
  $sql = "SELECT first_name, last_name, nif, email, address, created_at 
            FROM 013_customers 
            WHERE customer_id = $customer_id";
  $res = $conn->query($sql);
  if ($res && $res->num_rows > 0) {
    $customer = $res->fetch_assoc();
  }
}
$conn->close();
?>
<link rel="stylesheet" href="/student013/shop/backend/css/customers.css">
<div class="container">
  <h1>Your profile</h1>

  <?php if ($customer): ?>
    <?php
    $name = htmlspecialchars(($customer['first_name'] ?? '') . ' ' . ($customer['last_name'] ?? ''));
    $email = htmlspecialchars($customer['email'] ?? '');
    $nif = htmlspecialchars($customer['nif'] ?? '');
    $address = htmlspecialchars($customer['address'] ?? '');
    $createdAt = htmlspecialchars($customer['created_at'] ?? '');
    ?>
    <div class="customer-card">
      <img src="/student013/shop/assets/icons/user.svg" alt="Foto de <?= $name ?>" class="customer-img">
      <h3><?= $name ?: 'Sin nombre' ?></h3>
      <p><strong>Email:</strong> <?= $email ?></p>
      <p><strong>NIF:</strong> <?= $nif ?></p>
      <p><strong>Dirección:</strong> <?= $address ?></p>
      <p><strong>Registrado el:</strong> <?= $createdAt ?></p>
      <div class="buttons">
        <a href="/student013/shop/backend/database/db_customers/db_customer_update.php?customer_id=<?= $customer_id ?>"
          class="update">Actualizar</a>
        <a href="/student013/shop/backend/database/db_customers/db_customer_delete.php?customer_id=<?= $customer_id ?>"
          class="delete">Eliminar</a>
      </div>
    </div>
  <?php elseif ($customer_id > 0 && $canAccess): ?>
    <p>Cliente no encontrado.</p>
  <?php else: ?>
    <p>No tienes permisos para ver este perfil.</p>
  <?php endif; ?>
</div>
<?php require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>