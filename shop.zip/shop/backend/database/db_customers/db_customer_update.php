<?php
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$defaultImage = "/student013/shop/assets/icons/user.svg";
$customer_id = intval($_GET['customer_id'] ?? ($_SESSION['customer_id'] ?? 0));
$canEdit = ($userType === 'admin') || $userType === 'customer' && $_SESSION['customer_id'] == $customer_id;

// Procesar actualización
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $canEdit) {
  $customer_id = intval($_POST['customer_id'] ?? 0);
  $first_name = $conn->real_escape_string($_POST['first_name'] ?? '');
  $last_name = $conn->real_escape_string($_POST['last_name'] ?? '');
  $nif = $conn->real_escape_string($_POST['nif'] ?? '');
  $email = $conn->real_escape_string($_POST['email'] ?? '');
  $address = $conn->real_escape_string($_POST['address'] ?? '');
  $phone = $conn->real_escape_string($_POST['phone'] ?? '');
  $city = $conn->real_escape_string($_POST['city'] ?? '');
  $zip_code = $conn->real_escape_string($_POST['zip_code'] ?? '');
  $country = $conn->real_escape_string($_POST['country'] ?? '');

  // Imagen de perfil
  $imageSql = "";
  if (!empty($_FILES['image']['name'])) {
    $uploadDir = $_SERVER['DOCUMENT_ROOT'] . "/student013/shop/assets/img/";
    if (!is_dir($uploadDir)) {
      mkdir($uploadDir, 0777, true);
    }
    $fileName = time() . "_" . basename($_FILES['image']['name']);
    $targetFile = $uploadDir . $fileName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
      $imagePath = "/student013/shop/assets/img/" . $fileName;
      $imageSql = ", image='$imagePath'";
      $_SESSION['user_image'] = $imagePath;
    }
  }

  $sql_update = "UPDATE 013_customers SET 
                      first_name='$first_name',
                      last_name='$last_name',
                      nif='$nif',
                      email='$email',
                      address='$address',
                      phone='$phone',
                      city='$city',
                      zip_code='$zip_code',
                      country='$country'
                      $imageSql
                  WHERE customer_id=$customer_id";

  echo $conn->query($sql_update)
    ? "<p style='color: green;'>Cliente actualizado correctamente.</p>"
    : "<p style='color: red;'>Error: " . htmlspecialchars($conn->error) . "</p>";
}
?>
<?php
if ($customer_id > 0 && $canEdit):
  $sql = "SELECT * FROM 013_customers WHERE customer_id=$customer_id";
  $result = $conn->query($sql);
  if ($result && $row = $result->fetch_assoc()):
?>
    <link rel="stylesheet" href="/student013/shop/backend/css/customers.css">
    <div class="container-form">
      <h1>Actualizar Cliente</h1>
      <div class="profile-update">
        <div class="profile-image">
          <img src="<?= htmlspecialchars($row['image'] ?: $defaultImage) ?>"
            alt="Foto de <?= htmlspecialchars($row['first_name']) ?>" class="profile-icon">
        </div>
        <form method="POST" action="" enctype="multipart/form-data" class="profile-form">
          <input type="hidden" name="customer_id" value="<?= $customer_id ?>">
          <p>
            <label>Nombre:</label>
            <input type="text" name="first_name" value="<?= htmlspecialchars($row['first_name']) ?>" required>
          </p>

          <p>
            <label>Apellidos:</label>
            <input type="text" name="last_name" value="<?= htmlspecialchars($row['last_name']) ?>" required>
          </p>

          <p>
            <label>NIF:</label>
            <input type="text" name="nif" value="<?= htmlspecialchars($row['nif']) ?>" required>
          </p>

          <p>
            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($row['email']) ?>" required>
          </p>

          <p>
            <label>Teléfono:</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($row['phone']) ?>">
          </p>

          <p>
            <label>Dirección:</label>
            <input type="text" name="address" value="<?= htmlspecialchars($row['address']) ?>">
          </p>

          <p>
            <label>Ciudad:</label>
            <input type="text" name="city" value="<?= htmlspecialchars($row['city']) ?>">
          </p>

          <p>
            <label>Código Postal:</label>
            <input type="text" name="zip_code" value="<?= htmlspecialchars($row['zip_code']) ?>">
          </p>

          <p>
            <label>País:</label>
            <input type="text" name="country" value="<?= htmlspecialchars($row['country']) ?>">
          </p>
          <p>
            <input type="submit" value="Guardar cambios" class="update">
          </p>
        </form>
      </div>
    </div>
<?php else:
    echo "<p>Cliente no encontrado.</p>";
  endif;
else:
  echo "<p>No tienes permisos para editar este perfil.</p>";
endif; ?>
<?php
$conn->close();
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php';
?>