<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $first_name = $conn->real_escape_string($_POST["first_name"] ?? '');
    $last_name = $conn->real_escape_string($_POST["last_name"] ?? '');
    $nif = $conn->real_escape_string($_POST["nif"] ?? '');
    $email = $conn->real_escape_string($_POST["email"] ?? '');
    $password = $_POST["password"] ?? ''; // se hashea, no se escapa
    $address = $conn->real_escape_string($_POST["address"] ?? '');
    $phone = $conn->real_escape_string($_POST["phone"] ?? '');
    $city = $conn->real_escape_string($_POST["city"] ?? '');
    $zip_code = $conn->real_escape_string($_POST["zip_code"] ?? '');
    $country = $conn->real_escape_string($_POST["country"] ?? '');

    $redirect_checkout_flow = ($_POST["redirect_checkout_flow"] ?? 'false') === 'true';
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Imagen de perfil
    $imagePath = "/student013/shop/assets/icons/user.svg";
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = $_SERVER['DOCUMENT_ROOT'] . "/student013/shop/assets/img/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $fileName = time() . "_" . basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imagePath = "/student013/shop/assets/img/" . $fileName;
        }
    }
    $sql = "INSERT INTO 013_customers (first_name, last_name, nif, email, password, address, phone, city, zip_code, country, image)
            VALUES ('$first_name', '$last_name', '$nif', '$email', '$hashedPassword', '$address', '$phone', '$city', '$zip_code', '$country', '$imagePath')";
    if ($conn->query($sql)) {
        if ($redirect_checkout_flow) {
            $url = "/student013/shop/backend/database/db_login.php?email=" . urlencode($email) .
                "&password=" . urlencode($password) . "&transfer_cart=true";
            header("Location: $url");
            $conn->close();
            exit;
        }
    }
}
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
?>
<link rel="stylesheet" href="/student013/shop/backend/css/products.css">
<div class="container">
    <h2>Resultado de inserción</h2>
    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if ($conn->affected_rows > 0) {
            echo "<p>Cliente <strong>" . htmlspecialchars($_POST["first_name"] ?? '') . " " . htmlspecialchars($_POST["last_name"] ?? '') . "</strong> insertado correctamente.</p>";
        } else {
            echo "<p>Error al insertar el cliente: " . htmlspecialchars($conn->error ?? 'Error desconocido') . "</p>";
        }
    } else {
        echo "<p>No se han recibido datos para insertar. Vuelve al formulario.</p>";
    }
    ?>
</div>
<?php
$conn->close();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php';
?>