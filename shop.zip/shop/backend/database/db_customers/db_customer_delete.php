<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

/* Variables y permisos */
$customer_id = intval($_GET['customer_id'] ?? 0);
$message = '';
$redirect = '';
$customer = null;
$canDelete = ($userType === 'admin') || $userType === 'customer' && !empty($_SESSION['customer_id']) && $_SESSION['customer_id'] == $customer_id;

/* Eliminar cliente */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirm'] ?? '') === 'yes') {
  $customer_id = intval($_POST['customer_id']);
  $sql_delete = "DELETE FROM 013_customers WHERE customer_id = $customer_id";
  if ($conn->query($sql_delete)) {
    $message = "Customer with ID <strong>$customer_id</strong> has been deleted correctly.";
    if ($userType === 'customer' && ($_SESSION['customer_id'] ?? 0) == $customer_id) {
      session_destroy();
      $redirect = '<p>Your account has been removed.<a href="/student013/shop/index.html">Return to homepage</a></p>';
    } else {
      $redirect = '<p><a href="/student013/shop/backend/forms/customers/customers_list.php">Return to customer list</a></p>';
    }
  } else {
    $message = "Error: " . htmlspecialchars($conn->error);
  }
}
/* Obtener cliente*/
if ($customer_id > 0 && $canDelete && empty($message)) {
  $sql_select = "SELECT first_name, last_name, email FROM 013_customers WHERE customer_id = $customer_id";
  $result = $conn->query($sql_select);
  if ($result && $result->num_rows === 1) {
    $customer = $result->fetch_assoc();
  }
}
$conn->close();
?>
<link rel="stylesheet" href="/student013/shop/backend/css/customers.css">
<div class="container">
  <h1>Delete Customer</h1>

  <?php if ($message): ?>
    <p><?= $message ?></p>
    <?= $redirect ?>
  <?php elseif ($customer): ?>
    <div class="customer-card">
      <h3><?= htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']) ?></h3>
      <p><strong>Email:</strong> <?= htmlspecialchars($customer['email']) ?></p>

      <h4 style="color:#c00;">Are you sure you want to delete your customer account?</h4>

      <form method="POST">
        <input type="hidden" name="customer_id" value="<?= $customer_id ?>">
        <input type="hidden" name="confirm" value="yes">
        <button type="submit" class="delete">Delete</button>
      </form>

      <form method="GET" action="<?= $userType === 'customer'
        ? '/student013/shop/backend/database/db_customers/db_customer_select.php'
        : '/student013/shop/backend/forms/customers/customers_list.php' ?>">
        <button type="submit" class="cancel">Cancel</button>
      </form>
    </div>
  <?php else: ?>
    <p>No valid customer ID or insufficient permissions.</p>
  <?php endif; ?>
</div>
<?php require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>