<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

function getExternalOrders($conn)
{
  $sql = "SELECT 
            o.order_id,
            o.order_number,
            o.updated_at,
            oi.product_name,
            oi.quantity,
            oi.price AS sale_price,
            p.partner_cost_price,
            (oi.quantity * oi.price) AS total_sale,
            (oi.quantity * p.partner_cost_price) AS total_cost,
            ((oi.quantity * oi.price) - (oi.quantity * p.partner_cost_price)) AS profit,
            pr.name
        FROM 013_order_items oi
        JOIN 013_orders o ON oi.order_id = o.order_id
        JOIN 013_products p ON oi.product_id = p.product_id
        JOIN 013_partners pr ON oi.partner_id = pr.partner_id
        WHERE oi.is_external = 1
        ORDER BY o.updated_at DESC
    ";

  return $conn->query($sql);
}