<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

function getPartnerBillingSummary($conn)
{
  $sql = "SELECT 
            partner_id,
            SUM(partner_total_cost) AS total_partner_cost,
            SUM(total_sale_amount) AS total_sales,
            SUM(profit) AS total_profit
        FROM partner_billing
        WHERE MONTH(order_date) = MONTH(CURRENT_DATE())
        AND YEAR(order_date) = YEAR(CURRENT_DATE())
        GROUP BY partner_id
    ";

  return $conn->query($sql);
}

function getPartnerBillingDetails($conn, $partner_id)
{
  $sql = "SELECT *
        FROM partner_billing
        WHERE partner_id = $partner_id
        AND MONTH(order_date) = MONTH(CURRENT_DATE())
        AND YEAR(order_date) = YEAR(CURRENT_DATE())
        ORDER BY order_date DESC
    ";

  return $conn->query($sql);
}