<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/resources/activity_log.php';

$email = $_GET['email'] ?? $_POST['email'] ?? '';
$password = $_GET['password'] ?? $_POST['password'] ?? '';
$transfer = isset($_GET['transfer_cart']);

// LOGIN ADMIN
$sqlAdmin = "SELECT admin_id, name, email, password FROM 013_admins WHERE email='$email'";
if ($result = $conn->query($sqlAdmin)) {
  if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    if (password_verify($password, $admin['password'])) {

      register_event("LOGIN ADMIN: {$admin['email']} con el ID {$admin['admin_id']} está logueado");

      $_SESSION['user_type'] = 'admin';
      $_SESSION['user_name'] = $admin['name'];
      $_SESSION['user_email'] = $admin['email'];
      $_SESSION['admin_id'] = $admin['admin_id'];

      header("Location: /student013/shop/backend/index.php");
      $conn->close();
      exit;
    }
  }
}

// LOGIN CUSTOMER
$sqlCustomer = "SELECT customer_id, first_name, last_name, email, password 
                FROM 013_customers WHERE email='$email'";
if ($result = $conn->query($sqlCustomer)) {
  if ($result->num_rows > 0) {
    $customer = $result->fetch_assoc();
    if (password_verify($password, $customer['password'])) {

      register_event("LOGIN CUSTOMER: {$customer['email']} con el ID {$customer['customer_id']} está logueado");

      $customer_id = $customer['customer_id'];
      $_SESSION['user_type'] = 'customer';
      $_SESSION['user_name'] = $customer['first_name'] . ' ' . $customer['last_name'];
      $_SESSION['user_email'] = $customer['email'];
      $_SESSION['customer_id'] = $customer_id;

      if ($transfer && isset($_COOKIE['guest_id']) && is_numeric($_COOKIE['guest_id'])) {
        $guest_id = intval($_COOKIE['guest_id']);
        $conn->query("UPDATE 013_shopping_cart 
                      SET customer_id=$customer_id, guest_id=NULL 
                      WHERE guest_id=$guest_id");

        setcookie('guest_id', '', time() - 3600, "/");
        header("Location: /student013/shop/views/carrito.html");
      } else {
        header("Location: /student013/shop/index.html");
      }

      $conn->close();
      exit;
    }
  }
}

register_event("LOGIN FALLIDO: $email");

echo "<p>Credenciales incorrectas.</p>";
$conn->close();
?>