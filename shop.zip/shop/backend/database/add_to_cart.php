<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  exit(0);
}

session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/functions/cart_json_response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  cartJsonResponse(false, 'Método no permitido.');
}

// Leer JSON
$postData = file_get_contents('php://input');
$requestData = json_decode($postData, true);

if ($requestData === null) {
  cartJsonResponse(false, 'JSON inválido.');
}

// Extraer datos
$product_id = $requestData['product_id'] ?? null;
$variant_id = $requestData['variant_id'] ?? null;
$flavor = $requestData['flavor'] ?? null;
$quantity = $requestData['quantity'] ?? 1;

if (!is_numeric($product_id) || $product_id <= 0 || !is_numeric($quantity) || $quantity <= 0) {
  cartJsonResponse(false, 'Datos inválidos.');
}

$product_id = intval($product_id);
$variant_id = intval($variant_id);
$quantity = intval($quantity);

// Determinar cliente o invitado
$customer_id = $_SESSION['customer_id'] ?? null;
$guest_id = null;

if (!$customer_id) {
  if (!isset($_COOKIE['guest_id']) || !is_numeric($_COOKIE['guest_id'])) {
    $guest_id = mt_rand(100000, 999999);
    setcookie('guest_id', $guest_id, time() + 86400 * 3, "/");
  } else {
    $guest_id = intval($_COOKIE['guest_id']);
  }
}

// Obtener nombre del producto
$product_sql = "SELECT name FROM 013_products WHERE product_id = $product_id LIMIT 1";
$product_result = $conn->query($product_sql);

if (!$product_result || $product_result->num_rows === 0) {
  cartJsonResponse(false, 'El producto no existe.');
}

$product_name = $product_result->fetch_assoc()['name'];

// Insertar en carrito
$sql = "INSERT INTO 013_shopping_cart (customer_id, guest_id, product_id, variant_id, flavor, quantity)
        VALUES (" . ($customer_id ?: "NULL") . ", " . ($guest_id ?: "NULL") . ", $product_id, $variant_id, " . ($flavor ? "'$flavor'" : "NULL") . ", $quantity)
        ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)";

$conn->query($sql);
$conn->close();

cartJsonResponse(true, 'Producto añadido al carrito.', [
  'product_name' => $product_name,
  'quantity_added' => $quantity
]);
