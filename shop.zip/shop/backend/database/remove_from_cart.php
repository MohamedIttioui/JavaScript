<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/functions/cart_json_response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  cartJsonResponse(false, 'Método no permitido.');
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) cartJsonResponse(false, 'JSON inválido.');

$cart_id = intval($data['cart_id'] ?? 0);
if ($cart_id <= 0) cartJsonResponse(false, 'ID inválido.');

$sql = "DELETE FROM 013_shopping_cart WHERE shopping_cart_id = $cart_id";

if ($conn->query($sql)) {
  cartJsonResponse(true, 'Producto eliminado correctamente.');
} else {
  cartJsonResponse(false, 'Error en DB: ' . $conn->error);
}

$conn->close();
