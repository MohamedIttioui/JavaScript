<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/resources/activity_log.php';

if (isset($_SESSION['customer_id']) || isset($_SESSION['admin_id'])) {

  $email = $_SESSION['user_email'] ?? 'desconocido';
  register_event("LOGOUT: $email ha cerrado sesión");

  $_SESSION = [];
  session_destroy();
}

header("Location: /student013/shop/index.html");
exit;
?>