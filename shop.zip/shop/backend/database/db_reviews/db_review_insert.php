<?php
session_start();
header('Content-Type: application/json');
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$customer_id = $_SESSION['customer_id'] ?? null;
$guest_id = $_COOKIE['guest_id'] ?? null;

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

// Validar datos obligatorios
if (!$data || !isset($data['product_id']) || !isset($data['rating'])) {
    echo json_encode(["error" => "Datos incompletos"]);
    exit;
}

$product_id = intval($data['product_id']);
$order_id   = intval($data['order_id'] ?? 0);
$rating     = intval($data['rating']);
$comment    = $conn->real_escape_string($data['comment'] ?? "");

// Validar rating
if ($rating < 1 || $rating > 5) {
    echo json_encode(["error" => "Rating inválido"]);
    exit;
}

// Si no hay order_id - permitir review sin compra
$validate_purchase = $order_id > 0;

// Validar compra solo si hay order_id
if ($validate_purchase) {
    $sql = "SELECT * FROM 013_order_items WHERE order_id = $order_id AND product_id = $product_id";
    $res = $conn->query($sql);

    if (!$res || $res->num_rows === 0) {
        echo json_encode(["error" => "Este producto no pertenece al pedido"]);
        exit;
    }

    // Validar que el pedido pertenece al usuario
    $conditions = [];
    if ($customer_id) $conditions[] = "customer_id = $customer_id";
    if ($guest_id)    $conditions[] = "guest_id = '" . $conn->real_escape_string($guest_id) . "'";

    $where = implode(" OR ", $conditions);

    $sql = "SELECT * FROM 013_orders WHERE order_id = $order_id AND ($where)";
    $res = $conn->query($sql);

    if (!$res || $res->num_rows === 0) {
        echo json_encode(["error" => "No puedes valorar este pedido"]);
        exit;
    }

    // Evitar reviews duplicadas
    $sql = "SELECT * FROM 013_reviews WHERE order_id = $order_id AND product_id = $product_id AND ($where)";
    $res = $conn->query($sql);

    if ($res && $res->num_rows > 0) {
        echo json_encode(["error" => "Ya has valorado este producto"]);
        exit;
    }
}

// Insertar review
$sql = "INSERT INTO 013_reviews (product_id, order_id, customer_id, guest_id, rating, comment)
        VALUES (
            $product_id,
            " . ($order_id ?: "NULL") . ",
            " . ($customer_id ? $customer_id : "NULL") . ",
            " . ($guest_id ? "'" . $conn->real_escape_string($guest_id) . "'" : "NULL") . ",
            $rating,
            '$comment'
        )";
if (!$conn->query($sql)) {
    echo json_encode(["error" => "Error al guardar la review"]);
    exit;
}

echo json_encode(["success" => true, "message" => "Review creada"]);