<?php
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$product_id = intval($_GET['product_id']);

// Obtener reviews
$sql = "SELECT rating, comment, created_at 
        FROM 013_reviews 
        WHERE product_id = $product_id
        ORDER BY created_at DESC";

$res = $conn->query($sql);
$reviews = [];

while ($row = $res->fetch_assoc()) {
  $reviews[] = $row;
}

// Obtener media
$sql = "SELECT AVG(rating) AS avg_rating, COUNT(*) AS total_reviews
        FROM 013_reviews
        WHERE product_id = $product_id";

$stats = $conn->query($sql)->fetch_assoc();

echo json_encode([
  "reviews" => $reviews,
  "stats" => $stats
]);
