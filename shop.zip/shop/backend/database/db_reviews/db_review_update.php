<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/student013/shop/backend/db_connect.php";

function approve_review($id) {
    global $conn;
    $sql = "UPDATE 013_reviews SET is_approved = 1 WHERE id = $id";
    return $conn->query($sql);
}

function delete_review($id) {
    global $conn;
    $sql = "DELETE FROM 013_reviews WHERE id = $id";
    return $conn->query($sql);
}