<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

/* Variables iniciales */
$product_id = (int) ($_GET['product_id'] ?? 0);
$defaultImage = '/student013/shop/assets/img/whey_protein.jpg';
$product = null;

/* Obtener producto */
if ($product_id > 0) {
  $sql = "SELECT name, description, price, stock, vat_included, image FROM 013_products WHERE product_id = $product_id";
  $result = $conn->query($sql);
  if ($result && $result->num_rows === 1) {
    $product = $result->fetch_assoc();
  }
}
$conn->close();
?>
<link rel="stylesheet" href="/student013/shop/backend/css/products.css">
<div class="container">
  <h1>Product details</h1>
  <?php if ($product): ?>
    <?php
    $name = htmlspecialchars($product['name'] ?? 'Producto sin nombre');
    $description = htmlspecialchars($product['description'] ?? '');
    $price = htmlspecialchars($product['price'] ?? '0.00');
    $stock = htmlspecialchars($product['stock'] ?? '');
    $vat = $product['vat_included'] ? 'Sí' : 'No';
    $image = !empty($product['image']) ? $product['image'] : $defaultImage;
    ?>
    <div class="product-card">
      <img src="<?= $image ?>" alt="<?= $name ?>">
      <h3><?= $name ?></h3>
      <p><?= $description ?></p>
      <p><strong>Precio:</strong> €<?= $price ?></p>
      <p><strong>Stock:</strong> <?= $stock ?></p>
      <p><strong>IVA incluido:</strong> <?= $vat ?></p>

      <div class="buttons">
        <?php if ($userType === 'admin'): ?>
          <a href="/student013/shop/backend/forms/products/product_update.php?product_id=<?= $product_id ?>" class="update">Update</a>
          <a href="/student013/shop/backend/forms/products/product_delete.php?product_id=<?= $product_id ?>" class="delete">Delete</a>
        <?php endif; ?>
        <?php if ($userType === 'customer'): ?>
          <a href="/student013/shop/backend/database/add_to_cart.php?product_id=<?= $product_id ?>" class="update">Add to cart</a>
        <?php endif; ?>
      </div>
    </div>
  <?php elseif ($product_id > 0): ?>
    <p>Producto no encontrado.</p>
  <?php else: ?>
    <p>No se ha proporcionado un ID válido.</p>
  <?php endif; ?>
</div>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>