<?php 
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php'; ?>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php'; ?>
<link rel="stylesheet" href="/student013/shop/backend/css/products.css">
<div class="container">
    <h2>Resultado de inserción</h2>

    <?php if ($_SERVER["REQUEST_METHOD"] === "POST") :
        $name = $_POST["name"];
        $description = $_POST["description"];
        $price = floatval($_POST["price"]);
        $stock = intval($_POST["stock"]);
        $vat = isset($_POST["vat_included"]) ? 1 : 0;

        $sql = "INSERT INTO 013_products (name, description, price, stock, vat_included)
            VALUES ('$name', '$description', $price, $stock, $vat)";

        if ($conn->query($sql)) :
            echo "<p>Producto <strong>" . htmlspecialchars($name) . "</strong> insertado correctamente.</p>";
        else :
            echo "<p>Error al insertar el producto: " . htmlspecialchars($conn->error) . "</p>";
        endif;
    else : ?>
        <p>No se han recibido datos para insertar.</p>
    <?php endif; ?>
</div>

<?php $conn->close(); ?>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>