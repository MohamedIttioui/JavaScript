<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

/* Variables iniciales */
$product_id = intval($_GET['product_id'] ?? 0);
$message = '';
$product = null;

/* Actualizar producto */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
  $product_id = intval($_POST['product_id']);
  $name = $_POST['name'];
  $description = $_POST['description'];
  $price = floatval($_POST['price']);
  $stock = intval($_POST['stock']);
  $vat = isset($_POST['vat_included']) ? 1 : 0;

  $sql = "UPDATE 013_products SET
            name = '$name',
            description = '$description',
            price = $price,
            stock = $stock,
            vat_included = $vat
          WHERE product_id = $product_id";

  if ($conn->query($sql)) {
    $message = 'Producto actualizado correctamente.';
  } else {
    $message = 'Error al actualizar: ' . htmlspecialchars($conn->error);
  }
}
/* Obtener producto */
if ($product_id > 0) {
  $sql_select = "SELECT name, description, price, stock, vat_included FROM 013_products WHERE product_id = $product_id";
  $result = $conn->query($sql_select);
  if ($result && $result->num_rows === 1) {
    $product = $result->fetch_assoc();
  }
}
$conn->close();
?>
<link rel="stylesheet" href="/student013/shop/backend/css/products.css">
<div class="container">
  <h1>Update product</h1>
  <?php if ($message): ?>
    <p><?= $message ?></p>
  <?php endif; ?>
  <?php if ($product): ?>
    <form method="POST">
      <input type="hidden" name="product_id" value="<?= $product_id ?>">
      <p>
        <label>New name:</label><input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
      </p>
      <p>
        <label>New description:</label><textarea name="description"
          required><?= htmlspecialchars($product['description']) ?></textarea>
      </p>
      <p>
        <label>New price (€):</label><input type="number" step="0.01" name="price"
          value="<?= htmlspecialchars($product['price']) ?>" required>
      </p>
      <p>
        <label>New stock:</label><input type="number" name="stock" value="<?= htmlspecialchars($product['stock']) ?>"
          required>
      </p>
      <p>
        <label><input type="checkbox" name="vat_included" <?= $product['vat_included'] ? 'checked' : '' ?>>Vat
          included</label>
      </p>
      <p>
        <input type="submit" value="Save changes">
      </p>
    </form>
  <?php elseif ($product_id > 0): ?>
    <p>Producto no encontrado.</p>
  <?php else: ?>
    <p>No se ha proporcionado un ID válido.</p>
  <?php endif; ?>
</div>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>