<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

/* Variables iniciales */
$product_id = intval($_GET['product_id'] ?? 0);
$defaultImage = '/student013/shop/assets/img/whey_protein.jpg';
$message = '';
$product = null;

/* Eliminar producto */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirm'] ?? '') === 'yes') {
  $product_id = intval($_POST['product_id']);
  if ($conn->query("DELETE FROM 013_products WHERE product_id = $product_id")) {
    $message = "Product with ID <strong>$product_id</strong> has been deleted correctly.";
  } else {
    $message = "Error: " . htmlspecialchars($conn->error);
  }
}

/* Obtener producto */
if ($product_id > 0 && empty($message)) {
  $sql = "SELECT name, description, price, image FROM 013_products WHERE product_id = $product_id";
  $result = $conn->query($sql);
  if ($result && $result->num_rows === 1) {
    $product = $result->fetch_assoc();
  }
}
$conn->close();
?>
<link rel="stylesheet" href="/student013/shop/backend/css/products.css">
<div class="container">
  <h1>Delete product</h1>

  <?php if ($message): ?>
    <p><?= $message ?></p>
  <?php elseif ($product): ?>
    <?php
    $name = htmlspecialchars($product['name'] ?? 'Producto sin nombre');
    $description = htmlspecialchars($product['description'] ?? '');
    $price = htmlspecialchars($product['price'] ?? '0.00');
    $image = !empty($product['image']) ? $product['image'] : $defaultImage;
    ?>
    <div class="product-card">
      <img src="<?= $image ?>" alt="<?= $name ?>">
      <h3><?= $name ?></h3>
      <p><?= $description ?></p>
      <p><strong>Precio:</strong> €<?= $price ?></p>

      <h4 style="color:#c00;">Are you sure you want to delete this product?</h4>

      <form method="POST">
        <input type="hidden" name="product_id" value="<?= $product_id ?>">
        <input type="hidden" name="confirm" value="yes">
        <button type="submit" class="delete">Delete</button>
      </form>

      <form method="GET" action="/student013/shop/backend/forms/products/products_list.php">
        <button type="submit" class="cancel">Cancel</button>
      </form>
    </div>
  <?php elseif ($product_id > 0): ?>
    <p>Producto no encontrado.</p>
  <?php else: ?>
    <p>No se ha proporcionado un ID válido.</p>
  <?php endif; ?>
</div>
<?php require $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>