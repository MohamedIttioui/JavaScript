<?php
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/db_connect.php';

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
$canAccess = false;
$order = null;
$items = [];

if ($userType === 'admin') {
  $canAccess = true;
} elseif ($userType === 'customer' && !empty($_SESSION['customer_id'])) {
  $customer_id = intval($_SESSION['customer_id']);
  $sqlCheck = "SELECT customer_id FROM 013_orders WHERE order_id = $order_id";
  $resCheck = $conn->query($sqlCheck);
  if ($resCheck && $rowCheck = $resCheck->fetch_assoc()) {
    $canAccess = ($customer_id === intval($rowCheck['customer_id']));
  }
}
// Si tiene acceso, cargar datos del pedido y artículos
if ($order_id > 0 && $canAccess) {
  $sql = "SELECT o.order_number, o.order_date, o.total, o.status, c.first_name, c.last_name, c.email
            FROM 013_orders o
            JOIN 013_customers c ON o.customer_id = c.customer_id
            WHERE o.order_id = $order_id";
  $result = $conn->query($sql);
  if ($result && $result->num_rows > 0) {
    $order = $result->fetch_assoc();
  }
  $sqlItems = "SELECT oi.product_id, oi.product_name, oi.quantity, oi.price,
                        p.image, p.format, p.flavor
                 FROM 013_order_items oi
                 JOIN 013_products p ON oi.product_id = p.product_id
                 WHERE oi.order_id = $order_id";
  $resItems = $conn->query($sqlItems);
  if ($resItems && $resItems->num_rows > 0) {
    while ($row = $resItems->fetch_assoc()) {
      $items[] = $row;
    }
  }
}
$conn->close();
?>
<link rel="stylesheet" href="/student013/shop/backend/css/orders.css">
<div class="container">
  <h1>Detalle del pedido</h1>
  <?php if ($order_id > 0 && $canAccess && $order): ?>
    <div class="order-card">
      <img src="/student013/shop/assets/icons/orders.svg" alt="Orden <?= htmlspecialchars($order['order_number']) ?>"
        class="order-img">
      <h3>Orden <?= htmlspecialchars($order['order_number']) ?></h3>
      <p><strong>Cliente:</strong> <?= htmlspecialchars($order['first_name'] . ' ' . $order['last_name']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
      <p><strong>Fecha:</strong> <?= htmlspecialchars($order['order_date']) ?></p>
      <p><strong>Total:</strong> €<?= htmlspecialchars($order['total']) ?></p>
      <p><strong>Estado:</strong> <?= htmlspecialchars($order['status']) ?></p>

      <h4>Artículos</h4>
      <div class="order-items">
        <?php if (!empty($items)): ?>
          <?php foreach ($items as $item): ?>
            <div class="order-item">
              <a
                href="/student013/shop/views/product-detalle.html?product_id=<?= $item['product_id'] ?>&order_id=<?= $order_id ?>">
                <img src="<?= htmlspecialchars($item['image'] ?? '/student013/shop/assets/img/whey_protein.jpg') ?>"
                  alt="<?= htmlspecialchars($item['product_name']) ?>">
              </a>
              <div class="item-info">
                <h3><?= htmlspecialchars($item['product_name']) ?></h3>
                <p>Formato: <?= htmlspecialchars($item['format']) ?></p>
                <p>Sabor: <?= htmlspecialchars($item['flavor']) ?></p>
                <p>Cantidad: <?= intval($item['quantity']) ?></p>
                <p>Precio unitario: €<?= number_format((float) $item['price'], 2) ?></p>
                <p>Total: €<?= number_format(floatval($item['price']) * intval($item['quantity']), 2) ?></p>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p>No hay artículos en este pedido.</p>
        <?php endif; ?>
      </div>
      <div class="buttons">
        <a href="/student013/shop/backend/database/db_orders/db_order_update.php?order_id=<?= $order_id ?>"
          class="update">Actualizar</a>
        <a href="/student013/shop/backend/database/db_orders/db_order_delete.php?order_id=<?= $order_id ?>"
          class="delete">Eliminar</a>
        <?php if ($userType === 'admin'): ?>
          <a href="/student013/shop/backend/forms/orders/orders_list.php" class="select">Volver</a>
        <?php else: ?>
          <a href="#" class="select">Riviews</a>
        <?php endif; ?>
      </div>
    </div>
  <?php elseif ($order_id > 0 && $canAccess): ?>
    <p>Pedido no encontrado.</p>
  <?php else: ?>
    <p>No tienes permisos para ver este pedido.</p>
  <?php endif; ?>
</div>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/student013/shop/backend/footer.php'; ?>