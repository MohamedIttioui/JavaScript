<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/student013/shop/backend/db_connect.php";

function customer_has_bought_product($customer_id, $product_id)
{
  global $conn;

  $sql = "SELECT COUNT(*) AS total
        FROM orders o
        JOIN order_details od ON o.id = od.order_id
        WHERE o.customer_id = $customer_id
        AND od.product_id = $product_id
        AND o.status IN ('PAID','COMPLETED')
    ";

  $result = $conn->query($sql);
  $row = $result->fetch_assoc();

  return $row['total'] > 0;
}
