<?php

function test($name, $callback)
{
  echo "=== $name ===\n";
  try {
    $callback();
    echo "✔ OK\n\n";
  } catch (Exception $e) {
    echo "✘ ERROR: " . $e->getMessage() . "\n\n";
  }
}

function call_api($url, $apiKey = null)
{
  $opts = [
    "http" => [
      "method" => "GET",
      "header" => $apiKey ? "X-API-KEY: $apiKey\r\n" : ""
    ]
  ];
  $context = stream_context_create($opts);
  $response = file_get_contents($url, false, $context);
  return json_decode($response, true);
}

$ME_KEY = "b7c4f9e2d1a83c4f7b9d2a6c3f1e8b4d9c7a2f1b6e3d4c8a9f0b1c2d3e4f5a6";
$PARTNER_KEY = "d4f1c8a7b9e2f3c4a1d6e7b8c9f0a2b3d5e6c7a8b9f1d2c3e4f5a6b7c8d9e0f1";

$base = "http://localhost/student013/shop/backend/api";

test("Partner exporta productos", function () use ($base, $PARTNER_KEY) {
  $data = call_api("$base/partner/export_products.php", $PARTNER_KEY);
  if (!isset($data["products"]))
    throw new Exception("No devolvió productos");
});

test("ME importa productos del partner", function () use ($base, $ME_KEY) {
  $data = call_api("$base/me/import_from_partner.php", $ME_KEY);
  if (!isset($data["imported"]))
    throw new Exception("No importó productos");
});

test("ME exporta productos", function () use ($base, $ME_KEY) {
  $data = call_api("$base/me/export_products.php", $ME_KEY);
  if (!isset($data["products"]))
    throw new Exception("No devolvió productos");
});

test("Partner importa productos de ME", function () use ($base, $PARTNER_KEY) {
  $data = call_api("$base/partner/import_from_me.php", $PARTNER_KEY);
  if (!isset($data["imported"]))
    throw new Exception("No importó productos");
});

test("ME envía pedido al partner", function () use ($base, $ME_KEY) {
  $data = call_api("$base/me/send_cross_order.php?order_id=1", $ME_KEY);
  if (!isset($data["status"]))
    throw new Exception("No envió pedido");
});

test("Partner envía pedido a ME", function () use ($base, $PARTNER_KEY) {
  $data = call_api("$base/partner/send_cross_order.php?order_id=1", $PARTNER_KEY);
  if (!isset($data["status"]))
    throw new Exception("No envió pedido");
});

echo "=== PRUEBAS COMPLETADAS ===\n";