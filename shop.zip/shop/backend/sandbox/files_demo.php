<?php
/*
    EJEMPLOS BÁSICOS DE MANEJO DE ARCHIVOS EN PHP
    Usaremos siempre el archivo: log.txt
*/

/* 1. ESCRIBIR (APPEND) — AÑADIR TEXTO AL FINAL DEL ARCHIVO */

$archivo = fopen("log.txt", "a");   // "a" = abrir para añadir (crea si no existe)
fwrite($archivo, "Línea añadida con APPEND: " . date("Y-m-d H:i:s") . "\n");
fclose($archivo);

/* 2. ESCRIBIR (WRITE) — SOBRESCRIBIR TODO EL ARCHIVO*/

$archivo = fopen("log.txt", "w");   // "w" = sobrescribe todo el archivo
fwrite($archivo, "Archivo reiniciado completamente\n");
fwrite($archivo, "Segunda línea después del reinicio\n");
fclose($archivo);

/* 3. LEER TODO EL ARCHIVO DE UNA VEZ (file_get_contents) */

if (file_exists("log.txt")) { // Comprobamos si existe
  $contenido = file_get_contents("log.txt");  // Lee todo el archivo
  echo "<h3>Contenido completo del archivo:</h3>";
  echo nl2br($contenido); // nl2br convierte saltos de línea a <br>
}

/* 4. LEER LÍNEA POR LÍNEA (fgets) */
$srchivo = fopen("log.txt", "r");
$archivo = fopen("log.txt", "r");   // "r" = solo lectura

echo "<h3>Leyendo línea por línea:</h3>";

while (!feof($archivo)) {           // feof = end of file
  $linea = fgets($archivo);       // Lee una línea
  echo "Línea: $linea<br>";
}

fclose($archivo);

/* 5. LEER X BYTES (fread) */

$tamano = filesize("log.txt");      // Tamaño total del archivo en bytes
$archivo = fopen("log.txt", "r");

$contenido = fread($archivo, $tamano);  // Lee exactamente $tamano bytes
echo "<h3>Contenido leído con fread:</h3>";
echo nl2br($contenido);

fclose($archivo);

/* 6. ESCRIBIR RÁPIDO (file_put_contents) */

// Sobrescribe todo
file_put_contents("log.txt", "Texto reemplazado completamente con file_put_contents\n");

// Añadir sin borrar (FILE_APPEND)
file_put_contents("log.txt", "Nueva línea añadida con FILE_APPEND\n", FILE_APPEND);

/* 7. BLOQUEAR ARCHIVO MIENTRAS SE ESCRIBE (flock) */

$archivo = fopen("log.txt", "a");

if (flock($archivo, LOCK_EX)) {     // LOCK_EX = bloqueo exclusivo
  fwrite($archivo, "Entrada segura con bloqueo: " . time() . "\n");
  flock($archivo, LOCK_UN);       // Liberar bloqueo
}

fclose($archivo);


/* 8. LEER ARCHIVO COMO ARRAY (file) */
$lineas = file("log.txt", FILE_IGNORE_NEW_LINES); // Cada línea es un elemento del array

echo "<h3>Archivo leído como array:</h3>";

foreach ($lineas as $num => $linea) {
  echo "Línea $num: $linea<br>";
}