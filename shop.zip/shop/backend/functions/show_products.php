<?php
function show_products($conn, $userType, $searchItem = '')
{
  $defaultImage = '/student013/shop/assets/img/protein.png';

  // Si hay término de búsqueda, filtrar; si no, mostrar destacados
  if ($searchItem !== '') {
    $sql = "SELECT product_id, name, price, image 
            FROM 013_products 
            WHERE `name` LIKE '%" . $conn->real_escape_string($searchItem) . "%'";
  } else {
    $sql = "SELECT product_id, name, price, image 
            FROM 013_products 
            LIMIT 8";
  }
  $result = $conn->query($sql);
?>
  <div class="products-flex">
    <?php if ($result && $result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()):
        $product_id = htmlspecialchars($row['product_id']);
        $name       = htmlspecialchars($row['name'] ?? 'Producto sin nombre');
        $price      = htmlspecialchars($row['price'] ?? '0.00');
        $image      = !empty($row['image']) ? htmlspecialchars($row['image']) : $defaultImage;
      ?>
        <div class="product-card">
          <img src="<?= $image ?>" alt="<?= $name ?>">
          <h3><?= $name ?></h3>
          <p><strong>Price:</strong> €<?= $price ?></p>
          <div class="buttons">
            <?php if ($userType === 'admin'): ?>
              <a href="/student013/shop/backend/forms/products/product_select.php?product_id=<?= $product_id ?>" class="select">Show</a>
              <a href="/student013/shop/backend/forms/products/product_update.php?product_id=<?= $product_id ?>" class="update">Update</a>
              <a href="/student013/shop/backend/forms/products/product_delete.php?product_id=<?= $product_id ?>" class="delete">Delete</a>
            <?php else: ?>
              <a href="/student013/shop/views/product-detalle.html?product_id=<?= $product_id ?>" class="select">Show</a>
              <a href="/student013/shop/backend/database/add_to_cart.php?product_id=<?= $product_id ?>" class="update">Add to cart</a>
            <?php endif; ?>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No se encontraron productos que coincidan con la búsqueda: "<?= htmlspecialchars($searchItem) ?>".</p>
    <?php endif; ?>
  </div>
<?php
}
?>