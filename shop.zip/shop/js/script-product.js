document.addEventListener("DOMContentLoaded", () => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get("product_id");
    if (!productId) return;

    // Cargar bloque principal del producto
    fetch(`/student013/shop/backend/resources/product/render_product_main.php?product_id=${productId}`)
        .then(r => r.text())
        .then(html => {
            document.getElementById("product-detail").innerHTML = html;
            initVariantButtons();
        });

    // Cargar productos relacionados
    fetch(`/student013/shop/backend/resources/product/render_product_related.php?product_id=${productId}`)
        .then(r => r.text())
        .then(html => {
            document.getElementById("related-products").innerHTML = html;
        });

    // Cargar reviews
    fetch(`/student013/shop/backend/resources/product/render_product_reviews.php?product_id=${productId}`)
        .then(r => r.text())
        .then(html => {
            document.getElementById("product-reviews").innerHTML = html;
        });
});

async function submitReview(productId) {
    const rating = document.getElementById("review-rating").value;
    const comment = document.getElementById("review-comment").value;

    const payload = {
        product_id: productId,
        rating: rating,
        comment: comment
    };

    // Solo enviamos order_id si existe
    if (window.ORDER_ID) {
        payload.order_id = window.ORDER_ID;
    }

    const res = await fetch("/student013/shop/backend/database/db_reviews/db_review_insert.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    });

    const data = await res.json();

    document.getElementById("review-message").textContent =
        data.message || data.error;

    setTimeout(() => location.reload(), 1000);
}

//  VARIANTES
function initVariantButtons() {
    const buttons = document.querySelectorAll(".format-btn");
    const priceSpan = document.getElementById("product-price");
    const stockDiv = document.querySelector(".product-info .stock");

    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            buttons.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            const price = btn.dataset.price;
            const stock = btn.dataset.stock;

            if (priceSpan) priceSpan.textContent = `${parseFloat(price).toFixed(2)}€`;
            if (stockDiv) stockDiv.textContent = stock > 0 ? "En stock ✅" : "Sin stock ❌";
        });
    });
}

//  MENSAJE DINÁMICO
function showToastMessage(message, type) {
    const container = document.getElementById('container-message');
    if (!container) return;

    const toast = document.createElement('div');
    toast.classList.add('toast', type);
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('show');
    }, 10);

    setTimeout(() => {
        toast.classList.remove('show');
        toast.addEventListener('transitionend', () => toast.remove(), { once: true });
    }, 5000);
}


//  AÑADIR AL CARRITO
async function addToCart(productId) {

    const quantity = parseInt(document.getElementById("cantidad").value);

    const activeVariant = document.querySelector(".format-btn.active");
    const variantId = activeVariant ? activeVariant.dataset.variantId : null;

    const flavorSelect = document.getElementById("sabor");
    const flavor = flavorSelect ? flavorSelect.value : null;

    try {
        const response = await fetch('/student013/shop/backend/database/add_to_cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                product_id: productId,
                variant_id: variantId,
                flavor: flavor,
                quantity: quantity
            })
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            showToastMessage(data.message || 'No se pudo añadir el producto.', 'error');
            return;
        }

        showToastMessage(`${data.product_name} añadido (${quantity})`, 'success');

        if (typeof updateCartCount === "function") {
            await updateCartCount();
        }

    } catch (error) {
        console.error(error);
        showToastMessage(`Error de conexión: ${error.message}`, 'error');
    }
}