document.addEventListener("DOMContentLoaded", () => {
  const banner = document.getElementById("cookie-banner");

  if (!localStorage.getItem("cookie_consent")) {
    banner.style.display = "flex";
  }

  document.getElementById("cookie-accept").onclick = () => {
    localStorage.setItem("cookie_consent", "accepted");
    banner.style.display = "none";
  };

  document.getElementById("cookie-deny").onclick = () => {
    localStorage.setItem("cookie_consent", "denied");
    banner.style.display = "none";
  };

  document.getElementById("cookie-config").onclick = () => {
    alert("Aquí podrías abrir un modal con opciones avanzadas de cookies.");
  };
});