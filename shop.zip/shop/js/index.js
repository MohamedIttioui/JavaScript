// Actualiza el contador de productos en el carrito
async function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    if (!cartCount) return;

    try {
        // Llama al backend para obtener la suma de productos persistente
        const response = await fetch('/student013/shop/backend/resources/cart_count.php');
        const data = await response.json();
        // Asigna el conteo o 0 si es null/undefined
        cartCount.textContent = data.count || 0;
    } catch (err) {
        console.error('Error al actualizar contador de carrito', err);
        cartCount.textContent = '...';
    }
}

// Muestra un mensaje temporal en el contenedor principal del mensaje.
function showToastMessage(message, type) {
    const container = document.getElementById('container-message');
    if (!container) return;

    const toast = document.createElement('div');
    toast.classList.add('toast', type);
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('show');
    }, 10);

    setTimeout(() => {
        toast.classList.remove('show');
        toast.addEventListener('transitionend', () => toast.remove(), { once: true });
    }, 5000);
}

// Agrega un producto al carrito
async function addToCart(productId, quantity) {
    const qty = parseInt(quantity);
    try {
        const response = await fetch('/student013/shop/backend/database/add_to_cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId, quantity: qty })
        });
        const data = await response.json();
        if (!response.ok || !data.success) {
            showToastMessage(data.message || 'No se pudo añadir el producto.', 'error');
            return;
        }
        showToastMessage(`${data.product_name} añadido (${qty})`, 'success');
        await updateCartCount()
    } catch (error) {
        console.error(error);
        showToastMessage(`Error de conexión: ${error.message}`, 'error');
    }
}

// Cargar componentes (header / footer)
function loadComponent(endpointUrl, containerId) {
    const container = document.getElementById(containerId);
    if (!container) {
        console.error("No encontré el contenedor:", containerId);
        return;
    }
    fetch(endpointUrl)
        .then(response => {
            if (!response.ok) {
                container.innerHTML = '<p style="color:red;">Error al cargar el componente.</p>';
                return null;
            }
            return response.text();
        })
        .then(html => {
            if (!html) return;
            container.innerHTML = html;

            // Disparar evento cuando el header termina de cargarse
            if (containerId === "dynamic-header-container") {
                document.dispatchEvent(new Event("headerLoaded"));
            }
        });
}

// Cargar categorías desde el backend
function loadCategories() {
    fetch('/student013/shop/backend/resources/get_categories.php')
        .then(response => {
            if (!response.ok) {
                console.log("Error HTTP al cargar categorías:", response.status);
                return null;
            }
            return response.json();
        })
        .then(data => {
            if (!data || !data.success) {
                if (data) console.log("Error del backend al cargar categorías:", data.message);
                return;
            }
            renderCategories(data.categories);
        });
}

// Generar el menú de categorías y submenús
function renderCategories(categories) {
    const container = document.querySelector('.category-links');
    if (!container) return;

    container.innerHTML = "";
    categories.forEach(category => {
        const listItem = document.createElement('li');
        listItem.classList.add('category-item');
        const mainLink = document.createElement('a');
        mainLink.href = `/student013/shop/views/products.html?category_id=${category.category_id}`;
        mainLink.textContent = category.name;
        listItem.appendChild(mainLink);

        if (category.submenus && category.submenus.length > 0) {
            const submenuDiv = document.createElement('div');
            submenuDiv.classList.add('submenu');
            category.submenus.forEach(submenu => {
                const subLink = document.createElement('a');
                subLink.href = `/student013/shop/views/product-detalle.html?product_id=${submenu.product_id}`;
                subLink.textContent = submenu.name;
                submenuDiv.appendChild(subLink);
            });
            listItem.appendChild(submenuDiv);
        }
        container.appendChild(listItem);
    });
}

// Función de búsqueda
function searchProducts(searchItem) {
    const container = document.getElementById("products-container");
    const trimmed = searchItem.trim();

    if (trimmed.length === 0) {
        if (container) container.innerHTML = "";
        return;
    }
    const url = `/student013/shop/backend/resources/products_search.php?product_id=${encodeURIComponent(trimmed)}`;
    fetch(url)
        .then(response => {
            if (!response.ok) {
                if (container) { container.innerHTML = `<p class="error-message">Error ${response.status}</p>`; }
                return null;
            }
            return response.text();
        })
        .then(html => {
            if (!html) return;
            if (container) container.innerHTML = html;
        });
}

// Funciones de Carrusel y Productos Destacados
function initBannerSlider() {
    const banner = document.querySelector('.banner');
    if (!banner) return;

    const slidesContainer = banner.querySelector('.slides');
    if (!slidesContainer) {
        console.error("Error: No se encontró el contenedor '.slides'. Verifique render_banner.php.");
        return;
    }

    // Obtener las diapositivas DENTRO de ese contenedor y despues los puntos y los botones
    const slides = slidesContainer.querySelectorAll('.slide');
    const dotsContainer = banner.querySelector('.dots');
    const dots = dotsContainer ? dotsContainer.querySelectorAll('.dot') : [];
    const navBtns = banner.querySelectorAll('.nav-btn');
    let currentSlide = 0;
    let interval;

    // Si solo hay una promoción, el carrusel se detiene
    if (slides.length <= 1) return;

    // Función principal para mover el slider y actualizar el estado
    function updateSlide(i) {
        if (i >= slides.length) i = 0;
        if (i < 0) i = slides.length - 1;

        // Calcula el desplazamiento horizontal (translateX) y lo aplica al contenedor slides
        const offset = -i * 100;
        slidesContainer.style.transform = `translateX(${offset}%)`;

        // Actualizar la clase 'active' de los slides (para la primera carga)
        slides.forEach((s, j) => s.classList.toggle('active', j === i));

        // Actualizar la clase 'active' de los puntos (dots)
        dots.forEach((d, j) => d.classList.toggle('active', j === i));
        currentSlide = i;
    }

    function startAutoSlide() {
        interval = setInterval(() => updateSlide(currentSlide + 1), 5000);
    }
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            clearInterval(interval);
            updateSlide(currentSlide + (btn.classList.contains('right') ? 1 : -1));
            startAutoSlide();
        });
    });
    if (dotsContainer) {
        dotsContainer.addEventListener('click', e => {
            if (e.target.classList.contains('dot')) {
                clearInterval(interval);
                // El atributo data-slide indica qué índice debe mostrar
                updateSlide(parseInt(e.target.dataset.slide));
                startAutoSlide();
            }
        });
    }
    updateSlide(0);
    startAutoSlide();
}

async function loadBanner() {
    const container = document.querySelector('.banner');
    if (!container) return;
    try {
        const response = await fetch('/student013/shop/backend/resources/render_banner.php');
        const html = await response.text();
        container.innerHTML = html || '<div class="slide active"><div class="slide-inner"><h1 style="color:red;">Error de conexión</h1><p>No se pudo cargar el carrusel.</p></div></div>';
        initBannerSlider();
    } catch {
        container.innerHTML = '<div class="slide active"><div class="slide-inner"><h1 style="color:red;">Error de conexión</h1><p>No se pudo cargar el carrusel.</p></div></div>';
    }
}

async function loadFeaturedProducts() {
    const container = document.querySelector('.main-container');
    if (!container) return;
    container.innerHTML = '<h1 class="section-title">Nuestros Productos</h1><p style="text-align:center;">Cargando productos...</p>';
    try {
        const response = await fetch('/student013/shop/backend/resources/render_products.php');
        container.innerHTML = await response.text();
    } catch {
        container.innerHTML = '<h1 class="section-title">Nuestros Productos</h1><p class="error-message">Error al cargar productos destacados.</p>';
    }
}

// Inicialización cuando carga el DOM
document.addEventListener("DOMContentLoaded", () => {
    // 1. Listeners para navegación móvil
    const menuIcon = document.querySelector(".menu-icon");
    const closeMenu = document.querySelector(".close-menu");
    const categoryNav = document.querySelector(".category-nav");

    if (menuIcon && categoryNav) menuIcon.addEventListener("click", () => { if (window.innerWidth < 1024) { categoryNav.classList.add("active"); document.body.style.overflow = "hidden"; } });
    if (closeMenu && categoryNav) closeMenu.addEventListener("click", () => { categoryNav.classList.remove("active"); document.body.style.overflow = ""; });
    window.addEventListener("resize", () => { if (window.innerWidth >= 1024 && categoryNav) { categoryNav.classList.remove("active"); document.body.style.overflow = ""; } });

    // 2. Carga asíncrona de componentes principales
    loadComponent("/student013/shop/backend/header.php", "dynamic-header-container");
    loadComponent("/student013/shop/backend/footer.php", "dynamic-footer-container");

    // 3. Carga de contenido principal
    loadCategories();
    loadBanner();
    loadFeaturedProducts();
});

// Lógica que depende de que el header ya esté cargado
document.addEventListener("headerLoaded", () => {
    updateCartCount();

    // Toggle menú usuario
    const userMenu = document.querySelector('.user-menu');
    const userBtn = document.querySelector('.user-btn');
    if (userBtn && userMenu) {
        userBtn.addEventListener('click', e => { e.stopPropagation(); userMenu.classList.toggle('active'); });
        document.addEventListener('click', e => { if (!userMenu.contains(e.target)) userMenu.classList.remove('active'); });
    }

    // Toggle barra de búsqueda
    const searchBtn = document.querySelector('.search-btn');
    const searchContainer = document.querySelector('.search-container');
    const searchInput = document.getElementById('search-input');
    if (searchBtn && searchContainer) {
        searchBtn.addEventListener('click', e => {
            e.stopPropagation();
            searchContainer.classList.toggle('active');
            if (searchContainer.classList.contains('active')) searchInput.focus();
        });

        // Listener para ejecutar búsqueda al escribir
        searchInput.addEventListener('input', (e) => searchProducts(e.target.value));
    }
});