document.getElementById("btn-filter").addEventListener("click", loadLog);
document.getElementById("btn-download").addEventListener("click", downloadLog);
document.getElementById("btn-delete").addEventListener("click", deleteLog);

function loadLog() {
  const date = document.getElementById("date").value;
  const type = document.getElementById("type").value;
  const search = document.getElementById("search").value;
  const output = document.getElementById("output");

  fetch(`/student013/shop/backend/resources/get_logs.php?date=${date}&type=${type}&search=${search}`)
    .then(res => res.text())
    .then(data => {
      if (data === "NO_LOG") {
        output.innerHTML = `<div class="no-log">No hay registros para esta fecha.</div>`;
      } else if (data === "Acceso denegado") {
        output.innerHTML = `<div class="no-log">Acceso restringido solo para administradores.</div>`;
      } else {
        output.innerHTML = `<div class="log-box">${data}</div>`;
      }
    });
}

function downloadLog() {
  const date = document.getElementById("date").value;
  window.location = `/student013/shop/backend/resources/get_logs.php?action=download&date=${date}`;
}

function deleteLog() {
  const date = document.getElementById("date").value;

  if (!confirm("¿Seguro que deseas borrar este log?")) return;

  fetch(`/student013/shop/backend/api/get_logs.php?action=delete&date=${date}`)
    .then(res => res.text())
    .then(data => {
      if (data === "DELETED") {
        document.getElementById("output").innerHTML =
          `<div class="no-log">Log eliminado correctamente.</div>`;
      }
    });
}