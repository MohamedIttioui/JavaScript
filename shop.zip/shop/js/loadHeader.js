// Cargar componentes HTML (header / footer)
async function loadComponent(endpointUrl, containerId) {
  const container = document.getElementById(containerId);
  if (!container) {
    console.error("No encontré el contenedor:", containerId);
    return;
  }

  try {
    const response = await fetch(endpointUrl);
    if (!response.ok) {
      container.innerHTML = '<p style="color:red;">Error al cargar el componente.</p>';
      return;
    }
    const html = await response.text();
    container.innerHTML = html;

    // Aviso cuando el header termina de cargarse
    if (containerId === "dynamic-header-container") {
      document.dispatchEvent(new Event("headerLoaded"));
    }
  } catch (error) {
    console.error("Error al cargar componente:", error);
  }
}

// Buscar productos en el backend
async function searchProducts(searchItem) {
  const container = document.getElementById("products-container");
  const trimmed = searchItem.trim();

  // Si el usuario borra el campo, limpio los resultados
  if (trimmed.length === 0) {
    if (container) container.innerHTML = "";
    return;
  }

  try {
    const url = `/student013/shop/backend/resources/products_search.php?product_id=${encodeURIComponent(trimmed)}`;
    const response = await fetch(url);
    if (!response.ok) {
      if (container) container.innerHTML = `<p class="error-message">Error ${response.status}</p>`;
      return;
    }
    const html = await response.text();
    if (container) container.innerHTML = html;
  } catch (error) {
    console.error("Error al buscar productos:", error);
  }
}

// Generar el menú de categorías y submenús
function renderCategories(categories) {
  const container = document.querySelector('.category-links');
  if (!container) return;
  container.innerHTML = "";
  // Recorro todas las categorías recibidas del backend
  categories.forEach(category => {
    const listItem = document.createElement('li');
    listItem.classList.add('category-item');

    const mainLink = document.createElement('a');
    mainLink.href = `/views/products.html?category_id=${category.category_id}`;
    mainLink.textContent = category.name;
    listItem.appendChild(mainLink);

    if (category.submenus?.length > 0) {
      const submenuDiv = document.createElement('div');
      submenuDiv.classList.add('submenu');

      category.submenus.forEach(submenu => {
        const subLink = document.createElement('a');
        subLink.href = `/views/product-detalle.html?product_id=${submenu.product_id}`;
        subLink.textContent = submenu.name;
        submenuDiv.appendChild(subLink);
      });
      listItem.appendChild(submenuDiv);
    }
    container.appendChild(listItem);
  });
}

// Cargar categorías desde el backend
async function loadCategories() {
  try {
    const response = await fetch('/student013/shop/backend/resources/get_categories.php');
    if (!response.ok) {
      console.log("Error HTTP al cargar categorías:", response.status);
      return;
    }
    const data = await response.json();
    if (!data.success) {
      console.log("Error del backend al cargar categorías:", data.message);
      return;
    }
    // Si todo va bien, dibujo las categorías en pantalla
    renderCategories(data.categories);
  } catch (error) {
    console.error("Error al cargar categorías:", error);
  }
}

// Inicialización cuando carga la página
document.addEventListener("DOMContentLoaded", () => {
  loadComponent("/student013/shop/backend/header.php", "dynamic-header-container");
  loadComponent("/student013/shop/backend/footer.php", "dynamic-footer-container");
  loadCategories();
});