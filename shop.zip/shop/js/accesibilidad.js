function initAccesibilidad() {
  console.log("Inicializando accesibilidad");

  $("#btn-accesibilidad").on("click", () => {
    $("#accesibilidad-menu").toggle();
  });

  // CARGAR PREFERENCIAS
  const savedContrast = localStorage.getItem("contrast");
  const savedFont = localStorage.getItem("fontSize");
  const savedLine = localStorage.getItem("lineHeight");
  const savedWord = localStorage.getItem("wordSpacing");
  const savedLetter = localStorage.getItem("letterSpacing");

  if (savedContrast) $("body").addClass(savedContrast);
  if (savedFont) $("body").css("font-size", savedFont + "rem");
  if (savedLine) $("body").css("line-height", savedLine + "em");
  if (savedWord) $("body").css("word-spacing", savedWord + "em");
  if (savedLetter) $("body").css("letter-spacing", savedLetter + "em");

  let fontSize = savedFont ? parseFloat(savedFont) : 1;
  let lineHeight = savedLine ? parseFloat(savedLine) : 1.4;
  let wordSpacing = savedWord ? parseFloat(savedWord) : 0;
  let letterSpacing = savedLetter ? parseFloat(savedLetter) : 0;

  // CONTRASTES
  $(".contraste").click(function () {
    const mode = $(this).data("mode");

    $("body").removeClass("grayscale dark light sat-high sat-low");

    if (mode === "grayscale") $("body").addClass("grayscale");
    if (mode === "dark") $("body").addClass("dark");
    if (mode === "light") $("body").addClass("light");
    if (mode === "saturacion-alta") $("body").addClass("sat-high");
    if (mode === "saturacion-baja") $("body").addClass("sat-low");

    localStorage.setItem("contrast", mode);
  });

  // TAMAÑO DE LETRA
  $("#font-plus").click(() => {
    fontSize += 0.1;
    $("body").css("font-size", fontSize + "rem");
    localStorage.setItem("fontSize", fontSize);
  });

  $("#font-minus").click(() => {
    fontSize -= 0.1;
    $("body").css("font-size", fontSize + "rem");
    localStorage.setItem("fontSize", fontSize);
  });

  // INTERLINEADO
  $("#line-height-plus").click(() => {
    lineHeight += 0.1;
    $("body").css("line-height", lineHeight + "em");
    localStorage.setItem("lineHeight", lineHeight);
  });

  $("#line-height-minus").click(() => {
    lineHeight -= 0.1;
    $("body").css("line-height", lineHeight + "em");
    localStorage.setItem("lineHeight", lineHeight);
  });

  // ESPACIADO ENTRE PALABRAS
  $("#word-spacing-plus").click(() => {
    wordSpacing += 0.1;
    $("body").css("word-spacing", wordSpacing + "em");
    localStorage.setItem("wordSpacing", wordSpacing);
  });

  $("#word-spacing-minus").click(() => {
    wordSpacing -= 0.1;
    $("body").css("word-spacing", wordSpacing + "em");
    localStorage.setItem("wordSpacing", wordSpacing);
  });

  // ESPACIADO ENTRE LETRAS
  $("#letter-spacing-plus").click(() => {
    letterSpacing += 0.05;
    $("body").css("letter-spacing", letterSpacing + "em");
    localStorage.setItem("letterSpacing", letterSpacing);
  });

  $("#letter-spacing-minus").click(() => {
    letterSpacing -= 0.05;
    $("body").css("letter-spacing", letterSpacing + "em");
    localStorage.setItem("letterSpacing", letterSpacing);
  });

  $("#reset-accesibilidad").click(() => {
    localStorage.clear();
    location.reload();
  });
}


// Si el header ya existe (PHP), inicializamos ya
if (document.querySelector("#btn-accesibilidad")) {
  initAccesibilidad();
}

// Si el header se carga dinámicamente (HTML), esperamos al evento
document.addEventListener("headerLoaded", initAccesibilidad);