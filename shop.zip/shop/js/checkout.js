const RENDER_CHECKOUT_ENDPOINT = '/student013/shop/backend/resources/render_checkout_content.php';
const PROCESS_ORDER_ENDPOINT = '/student013/shop/backend/resources/process_order.php';

const checkoutContainer = document.getElementById('checkout-dynamic-content');

// Cargar el HTML del checkout
async function loadCheckoutContent() {
  if (!checkoutContainer) {
    console.error("Contenedor #checkout-dynamic-content no encontrado.");
    return;
  }

  try {
    const response = await fetch(RENDER_CHECKOUT_ENDPOINT, {
      credentials: "include"
    });

    if (!response.ok) {
      checkoutContainer.innerHTML = `
        <div class="alert alert-error">
          No se pudo cargar el checkout. Inicia sesión o revisa tu pedido.
        </div>`;
      return;
    }

    checkoutContainer.innerHTML = await response.text();
    bindCheckoutForm();

  } catch (error) {
    console.error("Error al cargar el checkout:", error);
    checkoutContainer.innerHTML = `
      <div class="alert alert-error">Error al cargar el checkout.</div>`;
  }
}

// Conectar el formulario dinámico
function bindCheckoutForm() {
  const form = document.getElementById("form-checkout");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = {
      shipping_address: document.getElementById("direccion").value,
      payment_method: document.querySelector("input[name='payment']:checked").value,
      comments: document.getElementById("comentarios").value
    };

    try {
      const response = await fetch(PROCESS_ORDER_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include"
      });

      const result = await response.json();

      if (!result.success) {
        alert(result.message);
        return;
      }

      window.location.href = "/student013/shop/views/payment.html";

    } catch (error) {
      console.error("Error enviando el pedido:", error);
      alert("Hubo un problema al procesar tu pedido.");
    }
  });
}

document.addEventListener('DOMContentLoaded', loadCheckoutContent);