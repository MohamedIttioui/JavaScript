// ENDPOINTS PHP
const cartLayoutContainer = document.querySelector('.cart-layout');
const messageDiv = document.getElementById('cart-message');

const ENDPOINTS = {
  render: '/student013/shop/backend/resources/render_cart_content.php',
  update: '/student013/shop/backend/database/update_cart_qty.php',
  remove: '/student013/shop/backend/database/remove_from_cart.php'
};

// Utilidad para enviar POST con JSON
async function postJSON(endpoint, data = {}) {
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return await response.json();
}

// Mostrar mensaje temporal
function showMessage(message, cssClass = 'success') {
  if (!messageDiv) return;
  messageDiv.textContent = message;
  messageDiv.className = cssClass;
  messageDiv.style.display = 'block';
  if (cssClass !== 'confirm') {
    setTimeout(() => messageDiv.style.display = 'none', 4000);
  }
}

// Mostrar confirmación con botones
function showConfirm(message, onYes, onNo) {
  if (!messageDiv) return;
  messageDiv.innerHTML = '';
  messageDiv.className = 'confirm';
  messageDiv.style.display = 'flex';

  const text = document.createElement('span');
  text.textContent = message;
  messageDiv.appendChild(text);

  ['Sí', 'No'].forEach((label, i) => {
    const btn = document.createElement('button');
    btn.textContent = label;
    btn.className = i === 0 ? 'yes' : 'no';
    btn.onclick = () => {
      messageDiv.style.display = 'none';
      i === 0 ? onYes() : onNo?.();
    };
    messageDiv.appendChild(btn);
  });
}

// Redirigir al checkout (sin llamar a process_order.php)
function redirectToCheckout() {
  window.location.href = '/student013/shop/views/checkout.html';
}

// Redirigir a inicio
function redirectToIndex() {
  window.location.href = '/student013/shop/index.html';
}

// Conectar botones del carrito
function CartButtons() {
  const summaryContainer = document.querySelector('.cart-summary');
  if (!summaryContainer) return;

  const checkoutBtn = summaryContainer.querySelector('.btn-primary');
  const continueBtn = summaryContainer.querySelector('.btn-ghost');

  checkoutBtn?.addEventListener('click', redirectToCheckout);
  continueBtn?.addEventListener('click', redirectToIndex);
}

// Cargar contenido del carrito
async function loadCartContent() {
  if (!cartLayoutContainer) return;
  try {
    const response = await fetch(ENDPOINTS.render);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const html = await response.text();
    cartLayoutContainer.innerHTML = html;
    CartButtons();
  } catch (error) {
    console.error("Error al cargar carrito:", error);
  }
}

// Actualizar cantidad
async function updateCartItem(cartId, newQuantity) {
  const quantity = parseInt(newQuantity);

  if (isNaN(quantity) || quantity <= 0) {
    showMessage('La cantidad debe ser un número positivo.', 'error');
    loadCartContent();
    return;
  }

  try {
    const data = await postJSON(ENDPOINTS.update, { cart_id: cartId, quantity });

    showMessage(data.message, data.success ? 'success' : 'error');
    loadCartContent();

  } catch (error) {
    console.error("Error al actualizar producto:", error);
  }
}

// Eliminar producto
function removeCartItem(cartId) {
  showConfirm('¿Eliminar este producto del carrito?', async () => {
    try {
      const data = await postJSON(ENDPOINTS.remove, { cart_id: cartId });

      showMessage(data.message, data.success ? 'success' : 'error');
      loadCartContent();

    } catch (error) {
      console.error("Error al eliminar producto:", error);
    }
  });
}

// Cargar carrito al iniciar
document.addEventListener('DOMContentLoaded', loadCartContent);