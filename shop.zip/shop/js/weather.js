const toggleBtn = document.getElementById("toggleSave");
const statusEl = document.getElementById("weather-status");
const tempEl = document.getElementById("current-temp");
const descEl = document.getElementById("current-desc");
const windEl = document.getElementById("current-wind");
const feelsEl = document.getElementById("current-feels");
const iconEl = document.getElementById("weather-icon");
const forecastContainer = document.getElementById("forecast-cards");

// Leer cookie
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
  return null;
}

let saveEnabled = getCookie("saveWeather") === "1";

// Actualizar visual
function updateToggleVisual() {
  if (saveEnabled) {
    toggleBtn.classList.add("active");
  } else {
    toggleBtn.classList.remove("active");
  }
}

toggleBtn.addEventListener("click", () => {
  saveEnabled = !saveEnabled;
  document.cookie = `saveWeather=${saveEnabled ? 1 : 0}; path=/`;
  updateToggleVisual();
});

// Mapa AccuWeather → Weather Icons
function getWeatherIcon(code) {
  const map = {
    1: "wi-day-sunny",
    2: "wi-day-cloudy",
    3: "wi-day-cloudy-high",
    4: "wi-cloud",
    5: "wi-cloudy",
    6: "wi-cloudy",
    7: "wi-cloudy",
    8: "wi-cloudy",
    11: "wi-fog",
    12: "wi-rain",
    13: "wi-rain-mix",
    14: "wi-showers",
    15: "wi-thunderstorm",
    16: "wi-storm-showers",
    17: "wi-thunderstorm",
    18: "wi-rain",
    19: "wi-snow",
    20: "wi-snow",
    21: "wi-snow-wind",
    22: "wi-snow",
    23: "wi-snow",
    24: "wi-sleet",
    25: "wi-sleet",
    26: "wi-rain-mix",
    29: "wi-rain-mix",
    30: "wi-hot",
    31: "wi-cold",
    32: "wi-windy",
    33: "wi-night-clear",
    34: "wi-night-alt-cloudy",
    35: "wi-night-alt-cloudy-high",
    36: "wi-night-alt-cloudy",
    37: "wi-night-alt-cloudy",
    38: "wi-night-alt-cloudy",
    39: "wi-night-alt-showers",
    40: "wi-night-alt-showers",
    41: "wi-night-alt-storm-showers",
    42: "wi-night-alt-storm-showers",
    43: "wi-night-alt-snow",
    44: "wi-night-alt-snow"
  };

  return map[code] || "wi-na";
}

// Formato fecha
function formatDateLabel(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString("es-ES", { weekday: "short", day: "numeric", month: "short" });
}

// Cargar tiempo
function loadWeather() {
  statusEl.textContent = "Cargando...";

  fetch("/student013/shop/backend/api/weather.php")
    .then(res => res.json())
    .then(data => {
      if (data.error) {
        statusEl.textContent = "Error al cargar el tiempo";
        return;
      }

      const current = data.current;
      const forecast = data.forecast;

      statusEl.textContent = current.WeatherText;
      tempEl.textContent = current.Temperature.Metric.Value + "°C";
      descEl.textContent = current.WeatherText;
      windEl.textContent = current.Wind.Speed.Metric.Value + " km/h";
      feelsEl.textContent = current.RealFeelTemperature.Metric.Value + "°C";

      // Icono principal
      iconEl.className = "wi weather-icon " + getWeatherIcon(current.WeatherIcon);

      // Forecast con iconos
      forecastContainer.innerHTML = forecast.map(day => `
        <div class="weather-forecast-card">
          <i class="wi weather-icon-small ${getWeatherIcon(day.Day.Icon)}"></i>
          <h4>${formatDateLabel(day.Date)}</h4>
          <p>Max: ${day.Temperature.Maximum.Value}°C</p>
          <p>Min: ${day.Temperature.Minimum.Value}°C</p>
        </div>
      `).join("");
    });
}

updateToggleVisual();
loadWeather();