async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('Error al cargar ' + url);
  return res.json();
}

// 3.1. Gráfico: pedidos e ingresos por mes
async function renderOrdersPerMonth() {
  const data = await fetchJSON('/student013/shop/backend/resources/stats_orders_month.php');

  const labels = data.map(row => `${row.year}-${String(row.month).padStart(2, '0')}`);
  const orders = data.map(row => Number(row.total_orders));
  const revenue = data.map(row => Number(row.total_revenue));

  const ctx = document.getElementById('chartOrdersMonth').getContext('2d');

  new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'Pedidos',
          data: orders,
          borderColor: 'rgba(54, 162, 235, 1)',
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          yAxisID: 'y'
        },
        {
          label: 'Ingresos (€)',
          data: revenue,
          borderColor: 'rgba(75, 192, 192, 1)',
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      scales: {
        y: { type: 'linear', position: 'left' },
        y1: { type: 'linear', position: 'right' }
      }
    }
  });
}

// 3.2. Gráfico: top clientes por gasto
async function renderOrdersPerCustomer() {
  const data = await fetchJSON('/student013/shop/backend/resources/stats_orders_customer.php');

  const labels = data.map(row => row.customer_name);
  const spent = data.map(row => Number(row.total_spent));

  const ctx = document.getElementById('chartOrdersCustomer').getContext('2d');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Total gastado (€)',
        data: spent,
        backgroundColor: 'rgba(255, 159, 64, 0.6)'
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true
    }
  });
}

// 3.3. Gráfico: top productos por unidades
async function renderOrdersPerProduct() {
  const data = await fetchJSON('/student013/shop/backend/resources/stats_orders_product.php');

  const labels = data.map(row => row.product_name);
  const units = data.map(row => Number(row.total_units_sold));

  const ctx = document.getElementById('chartOrdersProduct').getContext('2d');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Unidades vendidas',
        data: units,
        backgroundColor: 'rgba(153, 102, 255, 0.6)'
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  renderOrdersPerMonth().catch(console.error);
  renderOrdersPerCustomer().catch(console.error);
  renderOrdersPerProduct().catch(console.error);
});